﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EFMigrations
{
    class Program
    {
        static void Main(string[] args)
        {
            using (var db = new EmployeeContext())
            {
                db.Departments.Add(new Department { DepartmentName = "Development", DepartmentCode = "dep001"});
                db.SaveChanges();

                foreach (var department in db.Departments)
                {
                    Console.WriteLine(department.DepartmentName);
                }
            }

            Console.WriteLine("Press any key to exit...");
            Console.ReadKey();
        }
    }
}
