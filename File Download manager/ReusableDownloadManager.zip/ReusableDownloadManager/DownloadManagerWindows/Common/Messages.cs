﻿//@filename: Messages.cs
//
//@description: Messages class contains common messages used in the application. 
// Functionality includes: 1) Success and error messages used in the application.
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System.Collections;

/// <summary>
///  This is common classes namespace 
/// </summary>
namespace DownloadManager.Common
{
    /// <summary>
    /// Class contains display messages used in the application
    /// </summary>
    public class Messages
    {
        #region --Class Veriables--
        public static Hashtable _hashTable = new Hashtable();
        #endregion

        #region --Class Constructor--
        /// <summary>
        /// Initializes a new instance of the <see cref="Messages"/> class.
        /// </summary>
        public Messages()
        {
            //
            // TODO: Add constructor logic here
            //
            PopulateHashTable();
        }

        #endregion

        #region --Public Methods--

        /// <summary>
        /// Populates the hash table for storing messages.
        /// </summary>
        /// <remarks></remarks>
        public static void PopulateHashTable()
        {
            if (_hashTable.Count == 0)
            {

                #region --Common Messages--
                _hashTable.Add("VR-90000", "Confirm deletion");
                _hashTable.Add("VR-90001", "Error");
                _hashTable.Add("VR-90002", "Success");
                _hashTable.Add("VR-90003", "Ok");
                _hashTable.Add("VR-90004", "Cancel");
                _hashTable.Add("VR-90005", "Yes");
                _hashTable.Add("VR-90006", "No");
                _hashTable.Add("VR-90007", "Confirm");
                _hashTable.Add("VR-90008", "Cancel downloading");
                
                #endregion

                #region --Download Manager--
                _hashTable.Add("VR-110000", " Video download has been cancelled!");
                _hashTable.Add("VR-110001", " Video download has been paused!");
                _hashTable.Add("VR-110002", " Video download has been terminated and the video is removed from the system!");
                _hashTable.Add("VR-110003", " Video has been downloaded successfully!");
                _hashTable.Add("VR-110004", " Disk space is not available!");
                _hashTable.Add("VR-110005", " Video is downloading now!");
                _hashTable.Add("VR-110006", " Video download has been deleted!");
                _hashTable.Add("VR-110009", " Video is not available. Please try again!");
                _hashTable.Add("VR-110010", " Download Video ");
                _hashTable.Add("VR-110011", " Video is not loading. Please try again!");
                _hashTable.Add("VR-110012", " Problem occurred during downloading video. Please try again!");
                _hashTable.Add("VR-110013", " Problem occurred during delete video operation. Please try again!");
                _hashTable.Add("VR-110014", "Are you sure you want to delete the video permanently?\r\n");
                _hashTable.Add("VR-110015", "Are you sure you want to terminate the download process and remove the video permanently?\r\n");
                _hashTable.Add("VR-110016", "Preparing Online Video Library...\r\n");
                _hashTable.Add("VR-110017", "Unable to connect to the server. Please check net connection.\r\n");
                #endregion
            }
        }

        /// <summary>
        /// Gets the message.
        /// </summary>
        /// <param name="key">The key.</param>
        /// <returns></returns>
        public static string GetMessage(string key)
        {
            PopulateHashTable();
            object value = _hashTable[(object)key];
            return value.ToString();
        }

        #endregion
    }
}
