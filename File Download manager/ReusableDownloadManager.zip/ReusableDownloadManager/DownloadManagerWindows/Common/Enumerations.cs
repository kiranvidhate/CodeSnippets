﻿//@filename: Enumerations.cs
//
//@description: Enumerations class contains common enums used in the application. 
// Functionality includes: 1) Enumerations used in the application.
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

/// <summary>
///  This is common classes namespace 
/// </summary>
namespace DownloadManager.Common
{
    /// <summary>
    /// Class contains common enumerations used in the application
    /// </summary>
    public class Enumerations
    {

        #region --Class Constructor--

        /// <summary>
        /// Initializes a new instance of the <see cref="Enumerations"/> class.
        /// </summary>
        public Enumerations()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        #endregion

        #region --Inner Class--

        /// <summary>
        /// Class used for identifying string enumerations
        /// </summary>
        public class StringValue : System.Attribute
        {
            #region Class Variables

            private string _value;

            #endregion

            #region Class Properties

            public StringValue(string value)
            {
                _value = value;
            }

            public string Value
            {
                get { return _value; }
            }

            #endregion
        }

        #endregion

        #region --Class Enumerations--

        /// <summary>
        /// Enumeration Roles
        /// </summary>
        public enum MessageStatus
        {
            Failed = 0,
            Success = 1,
            Accepted = 3,
            Rejected = 4
        }

        /// <summary>
        /// Configuration Enumerations
        /// </summary>
        public enum Configurations
        {
            [StringValue("DateFormat")]
            DateFormat,

            [StringValue("LongDateFormat")]
            LongDateFormat,
        }

        /// <summary>
        /// Enumerations used for download manager
        /// </summary>
        public enum DownloadStatus
        {
            [StringValue("DownloadPaused")]
            DownloadPaused,

            [StringValue("DownloadDelete")]
            DownloadDelete,

            [StringValue("DownloadCancel")]
            DownloadCancel,

            [StringValue("DownloadStarted")]
            DownloadStarted,

            [StringValue("DownloadError")]
            DownloadError,

            [StringValue("DownloadComplete")]
            DownloadComplete,

            [StringValue("DownloadResume")]
            DownloadResume
        }

        /// <summary>
        /// Enumerations used for download process messages
        /// </summary>
        public enum DownloadProcessMessages
        {
            [StringValue("Red")]
            DownloadError,

            [StringValue("Green")]
            DownloadDone,

            [StringValue("Yellow")]
            DownloadWIP
        }

        #endregion

    }

}
