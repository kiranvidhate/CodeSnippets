﻿//@filename: Login.cs
//
//@description: This us static Login information class
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, VirtualRunner
//@version: V 1.0.0 Created on 02/23/2011  
//@created by Chandrashekhar Mahale
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

/// <summary>
///  This is common classes namespace 
/// </summary>
namespace DownloadManager.Common
{
    /// <summary>
    /// This static class maintains the Login information throughout the application.
    /// </summary>
    public static class LoginInfo
    {
        public static string UserID;
        public static string UserName;
        public static string FirstName;
        public static string LastName;
        public static int UserRoleId;

        public static System.Collections.Generic.List<string> lstVideoFiles;
    }
}
