﻿//@filename: Functions.cs
//
//@description: Functions class contains common functions used in the application. 
// Functionality includes:      1) Functions for parsing objects (i.e. To integer, decimal, etc.)
//                              2) Function for display error message.
//
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.Data;
using System.Reflection;
using System.Windows.Forms;
using System.Configuration;
using System.IO;

/// <summary>
///  This is common classes namespace 
/// </summary>
namespace DownloadManager.Common
{
    /// <summary>
    ///  This class contains common functions used in the application
    /// </summary>
    public static class Functions
    {
        #region --Public Methods--

        /// <summary>
        /// Parses the integer.
        /// </summary>
        /// <param name="intValue">The int value.</param>
        /// <returns></returns>
        public static int ParseInteger(string intValue)
        {
            int intVar = 0;
            int result = 0;

            if (!string.IsNullOrEmpty(intValue))
            {
                if (int.TryParse(intValue, out intVar))
                {
                    result = Convert.ToInt32(intValue);
                }
            }

            return result;
        }

        /// <summary>
        /// Parses the decimal.
        /// </summary>
        /// <param name="decValue">The dec value.</param>
        /// <returns></returns>
        public static decimal ParseDecimal(string decValue)
        {
            decimal decVar = 0;
            decimal result = 0;

            if (!string.IsNullOrEmpty(decValue))
            {
                if (decimal.TryParse(decValue, out decVar))
                {
                    result = Convert.ToDecimal(decValue);
                }
            }

            return result;
        }

        /// <summary>
        /// Parses the double.
        /// </summary>
        /// <param name="dobValue">The dob value.</param>
        /// <returns></returns>
        public static double ParseDouble(string dobValue)
        {
            double dobVar = 0;
            double result = 0;

            if (!string.IsNullOrEmpty(dobValue))
            {
                if (double.TryParse(dobValue, out dobVar))
                {
                    result = Convert.ToDouble(dobVar);
                }
            }

            return result;
        }

        /// <summary>
        /// Parses the string.
        /// </summary>
        /// <param name="strValue">The STR value.</param>
        /// <returns></returns>
        public static string ParseString(object strValue)
        {
            string result = string.Empty;

            if (strValue != null)
            {
                result = strValue.ToString();
            }

            return result;
        }

        /// <summary>
        /// Parses the long.
        /// </summary>
        /// <param name="lngValue">The LNG value.</param>
        /// <returns></returns>
        public static long ParseLong(string lngValue)
        {
            long lngVar = 0;
            long result = 0;

            if (!string.IsNullOrEmpty(lngValue))
            {
                if (long.TryParse(lngValue, out lngVar))
                {
                    result = Convert.ToInt64(lngVar);
                }
            }

            return result;
        }

        /// <summary>
        /// Parses the boolean.
        /// </summary>
        /// <param name="boolValue">The bool value.</param>
        /// <returns></returns>
        public static bool ParseBoolean(string boolValue)
        {
            bool decVar = false;
            bool result = false;

            if (!string.IsNullOrEmpty(boolValue))
            {
                if (bool.TryParse(boolValue, out decVar))
                {
                    result = Convert.ToBoolean(boolValue);
                }
            }

            if (!result)
            {
                result = boolValue.ToLower() == "yes";
            }
            else if (!result)
            {
                result = boolValue.ToLower() == "true";
            }

            return result;
        }

        /// <summary>
        /// Parses the date time.
        /// </summary>
        /// <param name="dateTimeValue">The date time value.</param>
        /// <returns></returns>
        public static DateTime ParseDateTime(string dateTimeValue)
        {
            DateTime dtDate = new DateTime();
            DateTime result = new DateTime(9999, 12, 31);
            //  IFormatProvider format = new CultureInfo("en-GB", true);

            if (!string.IsNullOrEmpty(dateTimeValue))
            {
                if (DateTime.TryParse(dateTimeValue, out dtDate))
                {
                    //result = Convert.ToDateTime(dateTimeValue, format);
                    result = Convert.ToDateTime(dateTimeValue);
                }
            }

            return result;
        }

        /// <summary>
        /// Determines whether the specified DataTableReader has column.
        /// </summary>
        /// <param name="dr">The dr.</param>
        /// <param name="columnName">Name of the column.</param>
        /// <returns>
        /// 	<c>true</c> if the specified dr has column; otherwise, <c>false</c>.
        /// </returns>
        public static bool HasColumn(DataTableReader dr, string columnName)
        {
            for (int i = 0; i < dr.FieldCount; i++)
            {
                if (dr.GetName(i).Equals(columnName, StringComparison.InvariantCultureIgnoreCase))
                    return true;
            }

            return false;
        }

        /// <summary>
        /// Validates the length of the string.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <param name="length">The length.</param>
        /// <returns></returns>
        public static bool ValidateStringLength(string value, int length)
        {
            return (value.Length <= length);
        }

        /// <summary>
        /// Formats the date.
        /// </summary>
        /// <param name="date">The date.</param>
        /// <returns></returns>
        public static string FormatDate(string date)
        {
            string dateFormat = ConfigurationSettings.AppSettings[Functions.GetStringEnumValue(Enumerations.Configurations.DateFormat)].ToString();
            return String.Format("{0:" + dateFormat + "}", ParseDateTime(date));
        }

        /// <summary>
        /// Determines whether [is null or empty] [the specified value].
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns>
        /// 	<c>true</c> if [is null or empty] [the specified value]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsNullOrEmpty(object value)
        {
            if (value != null)
            {
                return (string.IsNullOrEmpty(value.ToString()));
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// Gets the string enum value.
        /// </summary>
        /// <param name="value">The value.</param>
        /// <returns></returns>
        public static string GetStringEnumValue(Enum value)
        {
            string output = null;
            Type type = value.GetType();

            FieldInfo fi = type.GetField(value.ToString());
            DownloadManager.Common.Enumerations.StringValue[] attrs =
               fi.GetCustomAttributes(typeof(DownloadManager.Common.Enumerations.StringValue),
                                       false) as DownloadManager.Common.Enumerations.StringValue[];
            if (attrs.Length > 0)
            {
                output = attrs[0].Value;
            }

            return output;
        }

        /// <summary>
        /// Gets the AppDataPath folder's path.
        /// </summary>
        /// <returns></returns>
        public static string GetAppDataPath()
        {
            return Application.LocalUserAppDataPath.ToString();
        }


        /// <summary>
        /// Gets the common data path.
        /// </summary>
        /// <returns></returns>
        public static string GetCommonDataPath()
        {
            return Environment.GetFolderPath(Environment.SpecialFolder.CommonApplicationData);
        }

        /// <summary>
        /// Determines whether [is file exists] [the specified file name].
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        /// <returns>
        ///   <c>true</c> if [is file exists] [the specified file name]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsFileExists(string fileName)
        {
            return File.Exists(fileName);
        }

        /// <summary>
        /// Determines whether file is available and not locked for use.
        /// </summary>
        /// <param name="file">The file name.</param>
        /// <returns>
        ///   <c>true</c> if [is file locked] [the specified file]; otherwise, <c>false</c>.
        /// </returns>
        public static bool IsFileAvailable(string fileName)
        {
            FileStream stream = null;
            FileInfo file = new FileInfo(fileName);

            if (file.Exists)
            {
                try
                {
                    stream = file.Open(FileMode.Open, FileAccess.ReadWrite, FileShare.None);
                }
                catch (IOException e)
                {
                    //the file is unavailable because it is:
                    //still being written to
                    //or being processed by another thread
                    //or does not exist (has already been processed)
                    return false;
                }
                finally
                {
                    if (stream != null)
                        stream.Close();
                }
            }
            else
            {
                return false;
            }

            //file is available and not locked
            return true;
        }
        #endregion
    }
}


