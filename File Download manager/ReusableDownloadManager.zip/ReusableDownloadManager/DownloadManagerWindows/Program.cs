﻿//@filename: Program.cs
//
//@description: Class is the main entry point for the application.
// Functionality includes:      1) Main() invocation for the application.
//                              2) Initial form screen for the application
//                              3) Defines Unhandled event handler for the application.
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, VirtualRunner
//@version: V 1.0.0 Created on 02/16/2011
//@created by Kiran Vidhate

using System;
using System.Collections.Generic;
using System.Linq;
using System.Windows.Forms;
using DownloadManager.View;
using DownloadManager.Common;


namespace DownloadManager
{
    /// <summary>
    /// Class is the main entry point for the application.
    /// </summary> 
    static class Program
    {
        /// <summary>
        /// The main entry point for the application.
        /// </summary>
        [STAThread]
        static void Main()
        {
            Application.EnableVisualStyles();
            Application.SetCompatibleTextRenderingDefault(false);
            Application.Run(new DownloadManager.View.DownloadManager());
        }
    }

}
