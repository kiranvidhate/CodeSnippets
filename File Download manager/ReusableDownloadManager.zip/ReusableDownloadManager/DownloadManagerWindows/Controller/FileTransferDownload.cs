//@filename: FileTransferDownload.cs
//
//@description: This class performs the Download file chunk by chunk  
//
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.ComponentModel;
using System.Diagnostics;
using System.IO;
using System.Management;
using DownloadManager.Common;
using DownloadManager.View;
using System.Windows.Forms;

namespace DownloadManager.Controller
{
    /// <summary>
    /// A class to download a file from a web server using web services
    /// Must specify the RemoteFileName and LocalSaveFolder before you call RunWorkerAsync() to begin the download
    /// </summary>
    public class FileTransferDownload : FileTransferBase
    {
        public string RemoteFileName;
        public string LocalSaveFolder;

        /// <summary>
        /// Start the download operation synchronously.
        /// The argument must be the start position, usually 0
        /// </summary>
        public void RunWorkerSync(DoWorkEventArgs e)
        {
            OnDoWork(e);
            base.OnRunWorkerCompleted(new RunWorkerCompletedEventArgs(e.Result, null, false));
        }

        /// <summary>
        /// Checks the disk space of the local computer in order to download file size
        /// </summary>
        public bool GetValidateFileSize(string fileName)
        {
            // The file is on the server and we need to know how big it is before we start downloading, in order to give accurate feedback to the user.
            long FileSize = this.WebService.GetFileSize(fileName);
            long driveFreeSize = GetFreeSpace();

            if (FileSize > driveFreeSize)
                return true;

            return false;
        }

        /// <summary>
        /// Returns disk space 
        /// </summary>
        public long GetFreeSpace()
        {

         string repoLocation = DownloadManagerCommon.GetRepositoryLocation();
         DriveInfo driveInfo = new DriveInfo(repoLocation);
         long FreeSpace = driveInfo.AvailableFreeSpace;

         return FreeSpace;

        }


        /// <summary>
        /// This method starts the download process. It supports cancellation, reporting progress, and exception handling.
        /// The argument is the start position, usually 0
        /// </summary>
        protected override void OnDoWork(DoWorkEventArgs e)
        {
            base.OnDoWork(e);

            this.Offset = long.Parse(e.Argument.ToString());  //>> need to set the last offset

            // This is used with a modulus of the sampleInterval to check if the chunk size should be adjusted.  
            // It is started at 1 so that the first check will be skipped because it may involve an initial delay in connecting to the web service
            int numIterations = 0;

            this.LocalFilePath = this.LocalSaveFolder.TrimEnd('\\') + "\\" + Path.GetFileNameWithoutExtension(RemoteFileName); //RemoteFileName;  
            this.RemoteFileExtension = Path.GetExtension(RemoteFileName);
            
            // create a new empty file
            if (Offset == 0 && File.Exists(this.LocalFilePath))
                File.Create(this.LocalFilePath).Close();

            // The file is on the server and we need to know how big it is before we start downloading, in order to give accurate feedback to the user.
            long FileSize = this.WebService.GetFileSize(this.RemoteFileName);
            string FileSizeDescription = CalcFileSize(FileSize);

            // open a file stream for the file we will write to in the start-up folder
            using (FileStream fs = new FileStream(LocalFilePath, FileMode.OpenOrCreate, FileAccess.Write))
            {

                fs.Seek(Offset, SeekOrigin.Begin);

                // download the chunks from the web service one by one, until all the bytes have been read, meaning the entire file has been downloaded.
                while (Offset < FileSize && !this.CancellationPending)
                {
                    try
                    {
                        // The DownloadChunk returns a byte[]
                        byte[] Buffer = this.WebService.DownloadChunk(this.RemoteFileName, this.Offset, ChunkSize);
                        fs.Write(Buffer, 0, Buffer.Length);

                        // save the offset position for resume
                        this.Offset += Buffer.Length;

                        if (isDeleted == true)
                        {
                            this.CancelAsync();
                            fs.Close();
                            fs.Dispose();

                            DownloadManagerCommon.DeleteFile(Path.GetFileNameWithoutExtension(LocalFilePath));
                            break;
                        }
                    }
                    catch (FileNotFoundException ex)
                    {
                        MessageBox.Show(Messages.GetMessage("VR-110009"), Messages.GetMessage("VR-110010"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (FileLoadException ex)
                    {
                        MessageBox.Show(Messages.GetMessage("VR-110011"), Messages.GetMessage("VR-110010"), MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    catch (Exception ex)
                    {
                        // swallow the exception and try again
                        if (NumRetries++ >= MaxRetries)	// too many retries, bail out
                        {
                            fs.Close();
                            isError = true;
                            MessageBox.Show(Messages.GetMessage("VR-110012"), Messages.GetMessage("VR-110010"), MessageBoxButtons.OK, MessageBoxIcon.Error);

                            break;
                        }
                    }

                    string SummaryText = string.Empty;
                    SummaryText = String.Format("Downloaded: {0} / {1}", CalcFileSize(Offset), FileSizeDescription);

                    this.ReportProgress((int)(((decimal)Offset / (decimal)FileSize) * 100), SummaryText);
                    numIterations++;
                }

            }
        }
    }
}

