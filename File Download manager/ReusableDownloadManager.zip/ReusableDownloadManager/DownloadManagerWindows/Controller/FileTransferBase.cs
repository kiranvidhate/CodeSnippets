//@filename: FileTransferBase.cs
//
//@description: This class set the Download functionality parameters
//
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.ComponentModel;
using System.Net;
using System.Threading;

namespace DownloadManager
{
    /// <summary>
    /// This class Contains functionality for the download file
    /// The BackgroundWorker class is used used to execute the huge operations in the background
    /// </summary>
    public class FileTransferBase : BackgroundWorker
    {

        protected MtomWebService.MTOMSoapClient ws;		// the web service object
        public int ChunkSize = 20 * 1024;				    // 4MB by default
        public int MaxRetries = 50;						    // max number of corrupted chunks or failed transfers to allow before giving up
        protected int NumRetries = 0;
        public long Offset = 0;						        // used in persisting the transfer position
        protected string LocalFileName;			            // the locally downloading file 
        protected DateTime StartTime;
        public string LocalFilePath;			           // this variable must be set prior to starting an Upload.  
        public string RemoteFileExtension;			       // the downloading file extension
        public long MaxRequestLength = 4096;	           // the default request size
        public string Guid;						           // used to track events when multiple file transfers are happening
        public int PreferredTransferDuration = 800;		   // milliseconds, the timespan the class will attempt to achieve for each chunk, to give responsive feedback on the progress bar.

        public event EventHandler ChunkSizeChanged;
        public bool isPaused;                            // to set if current downloading files status is cancelled
        public bool isDeleted;                              // to set if current downloading files status is deleted
        public bool isError;                                // to set if current downloading files got an error
        /// <summary>
        /// Constructor - set worker process properties
        /// </summary>
        public FileTransferBase()
        {
            base.WorkerReportsProgress = true;
            base.WorkerSupportsCancellation = true;
        }

        /// <summary>
        /// Creates web service instance
        /// </summary>
        public MtomWebService.MTOMSoapClient WebService
        {
            get
            {
                if (this.ws == null)
                {
                    ws = new MtomWebService.MTOMSoapClient();
                }
                return ws;
            }
            set
            {
                this.ws = value;
            }
        }

        protected override void Dispose(bool disposing)
        {
            base.Dispose(disposing);
        }

        /// <summary>
        /// Invokes when completed the back ground process
        /// </summary>
        protected override void OnRunWorkerCompleted(RunWorkerCompletedEventArgs e)
        {
            base.OnRunWorkerCompleted(e);
        }

        protected override void OnDoWork(DoWorkEventArgs e)
        {
            // Connect to the web service. if this step is not done here, it will retry 50 times because of the retry code...
            try
            {
                long webConfigSetting = this.WebService.GetMaxRequestLength();

                // set the max buffer size to slightly less than the request length to allow for SOAP message headers etc.  
                this.MaxRequestLength = Math.Max(1, (webConfigSetting * 1024) - (2 * 1024));
            }
            catch (Exception ex)
            {
                this.MaxRequestLength = 4000;
            }

            base.OnDoWork(e);
        }

        /// <summary>
        /// Returns a description of a number of bytes, in appropriate units.
        /// e.g. 
        ///		passing in 1024 will return a string "1 Kb"
        ///		passing in 1230000 will return "1.23 Mb"
        /// Megabytes and Gigabytes are formatted to 2 decimal places.
        /// Kilobytes are rounded to whole numbers.
        /// If the rounding results in 0 Kb, "1 Kb" is returned, because Windows behaves like this also.
        /// </summary>
        public static string CalcFileSize(long numBytes)
        {
            string fileSize = string.Empty;

            if (numBytes > 1073741824)
                fileSize = String.Format("{0:0.00} GB", (double)numBytes / 1073741824);
            else if (numBytes > 1048576)
                fileSize = String.Format("{0:0.00} MB", (double)numBytes / 1048576);
            else
                fileSize = String.Format("{0:0} KB", (double)numBytes / 1024);

            if (fileSize == "0 KB")
                fileSize = "0 KB";

            return fileSize;
        }

        // <summary>
        // Calculate the chunk size
        // </summary>
        //protected void CalcAndSetChunkSize()
        //{
        //    /* chunk size calculation is defined as follows 
        //     *		in the examples below, the preferred transfer time is 1500ms, taking one sample.
        //     *									  Example 1									Example 2
        //     *		Initial size				= 16384 bytes	(16k)						16384
        //     *		Transfer time for 1 chunk	= 800ms										2000 ms
        //     *		Average throughput / ms		= 16384b / 800ms = 20.48 b/ms				16384 / 2000 = 8.192 b/ms
        //     *		How many bytes in 1500ms?	= 20.48 * 1500 = 30720 bytes				8.192 * 1500 = 12228 bytes
        //     *		New chunksize				= 30720 bytes (speed up)					12228 bytes (slow down from original chunk size)
        //     */

        //    double transferTime = DateTime.Now.Subtract(this.StartTime).TotalMilliseconds;
        //    double averageBytesPerMilliSec = this.ChunkSize / transferTime;
        //    double preferredChunkSize = averageBytesPerMilliSec * this.PreferredTransferDuration;
        //    this.ChunkSize = (int)Math.Min(this.MaxRequestLength, Math.Max(4 * 1024, preferredChunkSize));	// set the chunk size so that it takes 1500ms per chunk (estimate), not less than 4Kb and not greater than 4mb // (note 4096Kb sometimes causes problems, probably due to the IIS max request size limit, choosing a slightly smaller max size of 4 million bytes seems to work nicely)			

        //    string statusMessage = String.Format("Chunk size: {0}{1}", CalcFileSize(this.ChunkSize), (this.ChunkSize == this.MaxRequestLength) ? " (max)" : "");
        //    if (this.ChunkSizeChanged != null)
        //        this.ChunkSizeChanged(statusMessage, EventArgs.Empty);
        //}
    }


}