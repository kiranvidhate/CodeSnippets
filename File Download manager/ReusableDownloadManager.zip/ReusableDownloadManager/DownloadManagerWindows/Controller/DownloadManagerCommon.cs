﻿//@filename: DownloadManagerCommon.cs
//
//@description: This is common method class for Download file process
//
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.IO;
using System.Configuration;
using DownloadManager.Common;
using System.Windows.Forms;

namespace DownloadManager.Controller
{

    /// <summary>
    /// This class provides common methods for download a file functionality
    /// </summary>
    public static class DownloadManagerCommon
    {

        /// <summary>
        /// This deletes the provided file from the repository location
        /// </summary>
        public static bool DeleteFile(string filePath)
        {
            //   int numItems = this.lstDownloadFiles.SelectedItems.Count;

            if (filePath != string.Empty)
                filePath = GetRepositoryLocation() + filePath;
            else
                return false;

            FileInfo file = new FileInfo(filePath);

            try
            {
                if (file.Exists)
                {
                    File.Delete(filePath);
                    return true;
                }
            }
            catch (Exception ex)
            {
                //.LogInfo(ex.Message.ToString());
            }

            return false;
        }

        /// <summary>
        /// This provides repository location disk drive
        /// </summary>
        public static string GetRepositoryLocation()
        {
            string repositoryLocation = ConfigurationSettings.AppSettings["DefaultVideoRepository"].ToString().Trim();
            return string.Concat(Application.StartupPath, "\\", repositoryLocation);
        }
    }
}
