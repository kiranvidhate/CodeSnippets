﻿namespace DownloadManager.View
{
    partial class DownloadManager
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grpboxResume = new System.Windows.Forms.Panel();
            this.btnResume = new System.Windows.Forms.Button();
            this.btnDelete = new System.Windows.Forms.Button();
            this.progressBarDownload = new System.Windows.Forms.ProgressBar();
            this.lblWelcome = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.lblStatus = new System.Windows.Forms.Label();
            this.lstDownloadFiles = new System.Windows.Forms.ListView();
            this.lblFileSizeDownload = new System.Windows.Forms.Label();
            this.grpboxStartDownload = new System.Windows.Forms.Panel();
            this.btnDownload = new System.Windows.Forms.Button();
            this.grpboxPaused = new System.Windows.Forms.Panel();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnPause = new System.Windows.Forms.Button();
            this.grpboxDownloadComplete = new System.Windows.Forms.Panel();
            this.btnDeleteDownloaded = new System.Windows.Forms.Button();
            this.btnStatus = new System.Windows.Forms.Button();
            this.grpboxResume.SuspendLayout();
            this.grpboxStartDownload.SuspendLayout();
            this.grpboxPaused.SuspendLayout();
            this.grpboxDownloadComplete.SuspendLayout();
            this.SuspendLayout();
            // 
            // grpboxResume
            // 
            this.grpboxResume.BackColor = System.Drawing.Color.Transparent;
            this.grpboxResume.Controls.Add(this.btnResume);
            this.grpboxResume.Controls.Add(this.btnDelete);
            this.grpboxResume.Location = new System.Drawing.Point(368, 191);
            this.grpboxResume.Name = "grpboxResume";
            this.grpboxResume.Size = new System.Drawing.Size(234, 43);
            this.grpboxResume.TabIndex = 68;
            this.grpboxResume.Visible = false;
            // 
            // btnResume
            // 
            this.btnResume.BackColor = System.Drawing.Color.Gray;
            this.btnResume.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnResume.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnResume.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnResume.ForeColor = System.Drawing.Color.White;
            this.btnResume.Location = new System.Drawing.Point(2, 0);
            this.btnResume.Name = "btnResume";
            this.btnResume.Size = new System.Drawing.Size(111, 39);
            this.btnResume.TabIndex = 25;
            this.btnResume.Text = "Resume";
            this.btnResume.UseVisualStyleBackColor = false;
            this.btnResume.Click += new System.EventHandler(this.btnResume_Click);
            // 
            // btnDelete
            // 
            this.btnDelete.BackColor = System.Drawing.Color.Gray;
            this.btnDelete.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDelete.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDelete.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDelete.ForeColor = System.Drawing.Color.White;
            this.btnDelete.Location = new System.Drawing.Point(120, 0);
            this.btnDelete.Name = "btnDelete";
            this.btnDelete.Size = new System.Drawing.Size(111, 39);
            this.btnDelete.TabIndex = 24;
            this.btnDelete.Text = "Delete";
            this.btnDelete.UseVisualStyleBackColor = false;
            this.btnDelete.Click += new System.EventHandler(this.btnDelete_Click);
            // 
            // progressBarDownload
            // 
            this.progressBarDownload.ForeColor = System.Drawing.Color.GreenYellow;
            this.progressBarDownload.Location = new System.Drawing.Point(368, 124);
            this.progressBarDownload.Name = "progressBarDownload";
            this.progressBarDownload.Size = new System.Drawing.Size(237, 19);
            this.progressBarDownload.TabIndex = 74;
            this.progressBarDownload.Visible = false;
            // 
            // lblWelcome
            // 
            this.lblWelcome.AutoSize = true;
            this.lblWelcome.BackColor = System.Drawing.Color.Transparent;
            this.lblWelcome.Font = new System.Drawing.Font("Verdana", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblWelcome.ForeColor = System.Drawing.Color.White;
            this.lblWelcome.Location = new System.Drawing.Point(13, 17);
            this.lblWelcome.Name = "lblWelcome";
            this.lblWelcome.Size = new System.Drawing.Size(306, 32);
            this.lblWelcome.TabIndex = 71;
            this.lblWelcome.Text = "Download Manager";
            // 
            // label1
            // 
            this.label1.BackColor = System.Drawing.Color.Transparent;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.White;
            this.label1.Location = new System.Drawing.Point(21, 96);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(203, 19);
            this.label1.TabIndex = 70;
            this.label1.Text = "Videos available for download:";
            // 
            // lblStatus
            // 
            this.lblStatus.BackColor = System.Drawing.Color.Transparent;
            this.lblStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblStatus.ForeColor = System.Drawing.Color.White;
            this.lblStatus.Location = new System.Drawing.Point(21, 67);
            this.lblStatus.Name = "lblStatus";
            this.lblStatus.Size = new System.Drawing.Size(663, 20);
            this.lblStatus.TabIndex = 69;
            this.lblStatus.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lstDownloadFiles
            // 
            this.lstDownloadFiles.BackColor = System.Drawing.Color.Black;
            this.lstDownloadFiles.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lstDownloadFiles.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lstDownloadFiles.ForeColor = System.Drawing.Color.White;
            this.lstDownloadFiles.FullRowSelect = true;
            this.lstDownloadFiles.GridLines = true;
            this.lstDownloadFiles.HeaderStyle = System.Windows.Forms.ColumnHeaderStyle.None;
            this.lstDownloadFiles.Location = new System.Drawing.Point(24, 120);
            this.lstDownloadFiles.MultiSelect = false;
            this.lstDownloadFiles.Name = "lstDownloadFiles";
            this.lstDownloadFiles.ShowItemToolTips = true;
            this.lstDownloadFiles.Size = new System.Drawing.Size(329, 300);
            this.lstDownloadFiles.Sorting = System.Windows.Forms.SortOrder.Ascending;
            this.lstDownloadFiles.TabIndex = 64;
            this.lstDownloadFiles.UseCompatibleStateImageBehavior = false;
            this.lstDownloadFiles.View = System.Windows.Forms.View.List;
            this.lstDownloadFiles.SelectedIndexChanged += new System.EventHandler(this.lstDownloadFiles_SelectedIndexChanged);
            // 
            // lblFileSizeDownload
            // 
            this.lblFileSizeDownload.BackColor = System.Drawing.Color.Transparent;
            this.lblFileSizeDownload.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFileSizeDownload.ForeColor = System.Drawing.Color.White;
            this.lblFileSizeDownload.Location = new System.Drawing.Point(369, 147);
            this.lblFileSizeDownload.Name = "lblFileSizeDownload";
            this.lblFileSizeDownload.Size = new System.Drawing.Size(281, 29);
            this.lblFileSizeDownload.TabIndex = 72;
            // 
            // grpboxStartDownload
            // 
            this.grpboxStartDownload.BackColor = System.Drawing.Color.Transparent;
            this.grpboxStartDownload.Controls.Add(this.btnDownload);
            this.grpboxStartDownload.Location = new System.Drawing.Point(369, 190);
            this.grpboxStartDownload.Name = "grpboxStartDownload";
            this.grpboxStartDownload.Size = new System.Drawing.Size(164, 42);
            this.grpboxStartDownload.TabIndex = 65;
            this.grpboxStartDownload.Visible = false;
            // 
            // btnDownload
            // 
            this.btnDownload.BackColor = System.Drawing.Color.Gray;
            this.btnDownload.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDownload.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDownload.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDownload.ForeColor = System.Drawing.Color.White;
            this.btnDownload.Location = new System.Drawing.Point(2, 1);
            this.btnDownload.Name = "btnDownload";
            this.btnDownload.Size = new System.Drawing.Size(111, 39);
            this.btnDownload.TabIndex = 30;
            this.btnDownload.Text = "Download";
            this.btnDownload.TextAlign = System.Drawing.ContentAlignment.TopLeft;
            this.btnDownload.UseVisualStyleBackColor = false;
            this.btnDownload.Click += new System.EventHandler(this.btnDownload_Click);
            // 
            // grpboxPaused
            // 
            this.grpboxPaused.BackColor = System.Drawing.Color.Transparent;
            this.grpboxPaused.Controls.Add(this.btnCancel);
            this.grpboxPaused.Controls.Add(this.btnPause);
            this.grpboxPaused.Location = new System.Drawing.Point(370, 191);
            this.grpboxPaused.Name = "grpboxPaused";
            this.grpboxPaused.Size = new System.Drawing.Size(236, 43);
            this.grpboxPaused.TabIndex = 66;
            this.grpboxPaused.Visible = false;
            // 
            // btnCancel
            // 
            this.btnCancel.BackColor = System.Drawing.Color.Gray;
            this.btnCancel.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnCancel.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnCancel.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.Location = new System.Drawing.Point(121, 0);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(111, 39);
            this.btnCancel.TabIndex = 23;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = false;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnPause
            // 
            this.btnPause.BackColor = System.Drawing.Color.Gray;
            this.btnPause.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnPause.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnPause.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnPause.ForeColor = System.Drawing.Color.White;
            this.btnPause.Location = new System.Drawing.Point(3, 0);
            this.btnPause.Name = "btnPause";
            this.btnPause.Size = new System.Drawing.Size(111, 39);
            this.btnPause.TabIndex = 21;
            this.btnPause.Text = "Pause";
            this.btnPause.UseVisualStyleBackColor = false;
            this.btnPause.Click += new System.EventHandler(this.btnPause_Click);
            // 
            // grpboxDownloadComplete
            // 
            this.grpboxDownloadComplete.BackColor = System.Drawing.Color.Transparent;
            this.grpboxDownloadComplete.Controls.Add(this.btnDeleteDownloaded);
            this.grpboxDownloadComplete.Controls.Add(this.btnStatus);
            this.grpboxDownloadComplete.Location = new System.Drawing.Point(369, 190);
            this.grpboxDownloadComplete.Name = "grpboxDownloadComplete";
            this.grpboxDownloadComplete.Size = new System.Drawing.Size(237, 43);
            this.grpboxDownloadComplete.TabIndex = 67;
            this.grpboxDownloadComplete.Visible = false;
            // 
            // btnDeleteDownloaded
            // 
            this.btnDeleteDownloaded.BackColor = System.Drawing.Color.Gray;
            this.btnDeleteDownloaded.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnDeleteDownloaded.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnDeleteDownloaded.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnDeleteDownloaded.ForeColor = System.Drawing.Color.White;
            this.btnDeleteDownloaded.Location = new System.Drawing.Point(121, 0);
            this.btnDeleteDownloaded.Name = "btnDeleteDownloaded";
            this.btnDeleteDownloaded.Size = new System.Drawing.Size(111, 39);
            this.btnDeleteDownloaded.TabIndex = 27;
            this.btnDeleteDownloaded.Text = "Delete";
            this.btnDeleteDownloaded.UseVisualStyleBackColor = false;
            this.btnDeleteDownloaded.Click += new System.EventHandler(this.btnDeleteDownloaded_Click);
            // 
            // btnStatus
            // 
            this.btnStatus.BackColor = System.Drawing.Color.Gray;
            this.btnStatus.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.btnStatus.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.btnStatus.Font = new System.Drawing.Font("Microsoft Sans Serif", 10F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnStatus.ForeColor = System.Drawing.Color.White;
            this.btnStatus.Location = new System.Drawing.Point(3, 0);
            this.btnStatus.Name = "btnStatus";
            this.btnStatus.Size = new System.Drawing.Size(111, 39);
            this.btnStatus.TabIndex = 26;
            this.btnStatus.Text = "Downloaded";
            this.btnStatus.UseVisualStyleBackColor = false;
            // 
            // DownloadManager
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.SystemColors.AppWorkspace;
            this.ClientSize = new System.Drawing.Size(629, 434);
            this.Controls.Add(this.grpboxResume);
            this.Controls.Add(this.progressBarDownload);
            this.Controls.Add(this.lblWelcome);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.lblStatus);
            this.Controls.Add(this.lstDownloadFiles);
            this.Controls.Add(this.lblFileSizeDownload);
            this.Controls.Add(this.grpboxStartDownload);
            this.Controls.Add(this.grpboxPaused);
            this.Controls.Add(this.grpboxDownloadComplete);
            this.Name = "DownloadManager";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Download Manager";
            this.grpboxResume.ResumeLayout(false);
            this.grpboxStartDownload.ResumeLayout(false);
            this.grpboxPaused.ResumeLayout(false);
            this.grpboxDownloadComplete.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Panel grpboxResume;
        private System.Windows.Forms.Button btnResume;
        private System.Windows.Forms.Button btnDelete;
        private System.Windows.Forms.ProgressBar progressBarDownload;
        private System.Windows.Forms.Label lblWelcome;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label lblStatus;
        private System.Windows.Forms.ListView lstDownloadFiles;
        private System.Windows.Forms.Label lblFileSizeDownload;
        private System.Windows.Forms.Panel grpboxStartDownload;
        private System.Windows.Forms.Button btnDownload;
        private System.Windows.Forms.Panel grpboxPaused;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnPause;
        private System.Windows.Forms.Panel grpboxDownloadComplete;
        private System.Windows.Forms.Button btnDeleteDownloaded;
        private System.Windows.Forms.Button btnStatus;

    }
}