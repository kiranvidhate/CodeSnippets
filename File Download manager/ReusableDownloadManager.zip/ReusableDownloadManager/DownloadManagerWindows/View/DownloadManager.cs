﻿//@filename: DownloadManager.cs
//
//@description: This is common method class for Download file process
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Windows.Forms;
using System.Threading;
using System.Web.UI;
using System.IO;
using DownloadManager.Controller;
using DownloadManager.Common;
using Ionic.Zip;


namespace DownloadManager.View
{
    public partial class DownloadManager : Form
    {
        #region Global Declaration

        public static MtomWebService.MTOMSoapClient WebService = new MtomWebService.MTOMSoapClient();
        public long partialOffset;
        public string currentThreadFile;
        public string downloadStatus = string.Empty;
        public int chunkSettingSize = 16;
        public bool btnPauseStatus;
        bool hasScriptExecuted = false;
        public string downloadPause = Functions.GetStringEnumValue(Enumerations.DownloadStatus.DownloadPaused).ToString();
        public string downloadDelete = Functions.GetStringEnumValue(Enumerations.DownloadStatus.DownloadDelete).ToString();
        public string downloadCanel = Functions.GetStringEnumValue(Enumerations.DownloadStatus.DownloadCancel).ToString();
        public string downloadDone = Functions.GetStringEnumValue(Enumerations.DownloadProcessMessages.DownloadDone).ToString();
        public string downloadError = Functions.GetStringEnumValue(Enumerations.DownloadProcessMessages.DownloadError).ToString();
        public string downloadWIP = Functions.GetStringEnumValue(Enumerations.DownloadProcessMessages.DownloadWIP).ToString();
        public string downloaFileLocation = DownloadManagerCommon.GetRepositoryLocation();

        delegate void updateResponseDelegate(string responseText, string statusColor);
        delegate void updateButtonDelegate(Panel currentState);
        delegate void updateProgressDelegate(string progressDetails);
        delegate void updateProgressBarDelegate(int progressPercentage);

        #endregion

        #region Form Events

        /// <summary>
        /// Initializes a new instance of the <see cref="OnlineVideo"/> class.
        /// </summary>
        public DownloadManager()
        {
            InitializeComponent();
            GetVideos();

            BindDownloadFileList();
        }

        /// <summary>
        /// Handles the Click event of the btnDownload control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnDownload_Click(object sender, EventArgs e)
        {
            string fileName;
            fileName = GetSelectedFile();

            downloadStatus = downloadWIP;
            CreateDownloadThread(0);
            UpdateButtonResponse(grpboxPaused);
            UpdateDownloadResponse(Messages.GetMessage("VR-110005"), downloadWIP);
            //.LogDownloadStatus(Enumerations.DownloadStatus.DownloadStarted, fileName);
        }

        /// <summary>
        /// Handles the Click event of the btnPause control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnPause_Click(object sender, EventArgs e)
        {
            downloadStatus = downloadPause;
            UpdateButtonResponse(grpboxResume);

            currentThreadFile = GetSelectedFile();
        }

        /// <summary>
        /// Handles the Click event of the btnDeleteDownloaded control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnDeleteDownloaded_Click(object sender, EventArgs e)
        {
            if (MessageWindow.Show(Messages.GetMessage("VR-110014"), Messages.GetMessage("VR-90000"), MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(Enumerations.MessageStatus.Accepted.ToString()))
            {
                DeleteSelectedFile(Enumerations.DownloadProcessMessages.DownloadDone);

            }
        }

        /// <summary>
        /// Handles the Click event of the btnCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (MessageWindow.Show(Messages.GetMessage("VR-110015"), Messages.GetMessage("VR-90008"), MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(Enumerations.MessageStatus.Accepted.ToString()))
            {
                downloadStatus = downloadDelete;
                currentThreadFile = GetSelectedFile();
            }
        }

        /// <summary>
        /// Handles the Click event of the btnDelete control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnDelete_Click(object sender, EventArgs e)
        {
            if (MessageWindow.Show(Messages.GetMessage("VR-110014"), Messages.GetMessage("VR-90000"), MessageBoxButtons.YesNo, MessageBoxIcon.Question).Equals(Enumerations.MessageStatus.Accepted.ToString()))
            {
                DeleteSelectedFile(Enumerations.DownloadProcessMessages.DownloadWIP);
            }
        }

        /// <summary>
        /// Handles the Click event of the btnResume control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnResume_Click(object sender, EventArgs e)
        {
            string fileName;

            fileName = GetSelectedFile();
            UpdateButtonResponse(grpboxPaused);
            ResumeDownload();

            UpdateDownloadResponse(Messages.GetMessage("VR-110005"), downloadWIP);
        }

        /// <summary>
        /// Handles the SelectedIndexChanged event of the lstDownloadFiles control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void lstDownloadFiles_SelectedIndexChanged(object sender, EventArgs e)
        {
            downloadStatus = string.Empty;
            currentThreadFile = GetSelectedFile();

            if (currentThreadFile != string.Empty)
                GetDownloadStatusByFile(currentThreadFile);
        }

        #endregion

        #region Supporting Functions


        /// <summary> 
        ///  Get the currently downloading file status
        /// </summary>
        private void GetDownloadStatusByFile(string fileName)
        {
            try
            {
                if (Path.GetExtension(fileName).Equals(".zip"))
                {
                    if (Directory.Exists(string.Concat(DownloadManagerCommon.GetRepositoryLocation(), Path.GetFileNameWithoutExtension(fileName))))
                    {
                        long totalFileSize = WebService.GetFileSize(fileName);
                        progressBarDownload.Value = 100;
                        lblFileSizeDownload.Text = String.Format("Downloaded: {0} / {1}", FileTransferBase.CalcFileSize(totalFileSize), FileTransferBase.CalcFileSize(totalFileSize));

                        DisplayDownloadButtons(totalFileSize, totalFileSize, false);
                        currentThreadFile = fileName;
                        progressBarDownload.Visible = true;
                    }
                    else
                    {
                        GetDownloadStatusByFileName(fileName);
                    }
                }
                else
                {
                    GetDownloadStatusByFileName(fileName);
                }
            }
            catch (Exception ex)
            {
                MessageWindow.Show(Messages.GetMessage("VR-110017"));
            }
        }

        /// <summary>
        /// Gets the name of the download status by file.
        /// </summary>
        /// <param name="fileName">Name of the file.</param>
        private void GetDownloadStatusByFileName(string fileName)
        {
            try
            {
                long downloadedFileSize = 0;
                long downloadingFileSize = 0;
                long totalFileSize = 0;
                grpboxStartDownload.Visible = fileName != string.Empty;
                bool downloadingFile = false;

                if (fileName != string.Empty)
                {
                    totalFileSize = WebService.GetFileSize(fileName);
                    downloadedFileSize = long.Parse(GetPartialDownloadedFileSize(fileName, totalFileSize));

                    //////Thread.Sleep(100);
                    System.Windows.Forms.Timer timerDelay = new System.Windows.Forms.Timer();
                    timerDelay.Interval = 500;
                    timerDelay.Start();
                    timerDelay.Stop();

                    downloadingFileSize = long.Parse(GetPartialDownloadedFileSize(fileName, totalFileSize));
                    progressBarDownload.Value = (int)(((decimal)downloadedFileSize / (decimal)totalFileSize) * 100);

                    if (downloadedFileSize != 0)
                        lblFileSizeDownload.Text = String.Format("Downloaded: {0} / {1}", FileTransferBase.CalcFileSize(downloadedFileSize), FileTransferBase.CalcFileSize(totalFileSize));
                    else
                        lblFileSizeDownload.Text = String.Format("Video Size: {0}", FileTransferBase.CalcFileSize(totalFileSize));

                    DisplayDownloadButtons(downloadedFileSize, totalFileSize, downloadingFile);
                    currentThreadFile = fileName;
                    progressBarDownload.Visible = true;
                }
                else
                    this.lblFileSizeDownload.Text = string.Empty;
            }
            catch (Exception ex)
            {
                MessageWindow.Show(Messages.GetMessage("VR-110017"));
            }
        }

        /// <summary> 
        ///  Get check the file downloading status - paused or not ?
        /// </summary>
        private bool CheckDownloadingStatus(long downloadedFileSize, long downloadingFileSize)
        {
            if (downloadedFileSize != downloadingFileSize)
                return true;
            else
                return false;
        }

        /// <summary> 
        ///  Display the buttons as per the downloading status
        /// </summary>
        private void DisplayDownloadButtons(long downloadedFileSize, long totalFileSize, bool status)
        {
            string fileName = GetSelectedFile();

            if (downloadedFileSize == totalFileSize)
            {
                UpdateButtonResponse(grpboxDownloadComplete);
                UpdateDownloadResponse(Messages.GetMessage("VR-110003"), downloadDone);
            }
            else if (status == true)
            {
                UpdateButtonResponse(grpboxPaused);
                UpdateDownloadResponse(Messages.GetMessage("VR-110005"), downloadWIP);
            }
            else if (downloadedFileSize > 0)
            {
                UpdateButtonResponse(grpboxResume);
                UpdateDownloadResponse(Messages.GetMessage("VR-110001"), downloadWIP);
            }
            else
            {
                UpdateButtonResponse(grpboxStartDownload);
                UpdateDownloadResponse(string.Empty, string.Empty);
            }
        }

        /// <summary> 
        /// This resumes file download process
        /// </summary>
        private void ResumeDownload()
        {
            string currentSelectedFile = GetSelectedFile();

            if (currentSelectedFile != string.Empty)
            {
                partialOffset = long.Parse(GetPartialDownloadedFileSize(Path.GetFileNameWithoutExtension(currentSelectedFile), 0));
                CreateDownloadThread(partialOffset);
                downloadStatus = string.Empty;
            }
        }

        /// <summary> 
        ///  Get the partial downloadeded file size
        /// </summary>
        public string GetPartialDownloadedFileSize(string fileName, long totalFileSize)
        {
            string fileSize;
            string fileWithoutExtension;
            string fileWithExtension;

            fileWithoutExtension = downloaFileLocation + Path.GetFileNameWithoutExtension(fileName);
            fileWithExtension = downloaFileLocation + fileName;

            if (File.Exists(fileWithoutExtension))
            {
                FileInfo fi = new FileInfo(fileWithoutExtension);
                fileSize = Convert.ToString(fi.Length);

                // The file completly downloaded but extension is not changed due to some reason like connection failure/application stopped/etc
                // Added to change the extension
                if (totalFileSize == long.Parse(fileSize))
                    File.Move(fileWithoutExtension, fileWithExtension);

            }
            else if (File.Exists(fileWithExtension))
            {
                FileInfo fi = new FileInfo(fileWithExtension);
                fileSize = Convert.ToString(fi.Length);
            }
            else
                fileSize = "0";


            return fileSize;
        }

        /// <summary> 
        ///  This deletes currently selected file from the local system
        /// </summary>
        private void DeleteSelectedFile(Enumerations.DownloadProcessMessages fileDownloadStatus)
        {
            string currentSelectedFile = GetSelectedFile();
            bool isZipFile = false;

            if (currentSelectedFile != string.Empty)
            {
                UpdateDownloadingStatusMessage(currentSelectedFile);
                UpdateDownloadProgressBarResponse(0);

                if (fileDownloadStatus == Enumerations.DownloadProcessMessages.DownloadWIP)
                {
                    currentSelectedFile = Path.GetFileNameWithoutExtension(currentSelectedFile);
                }
                else if (fileDownloadStatus == Enumerations.DownloadProcessMessages.DownloadDone)
                {
                    if (Path.GetExtension(currentSelectedFile).Equals(".zip"))
                    {
                        string videoFolder = string.Concat(DownloadManagerCommon.GetRepositoryLocation(), Path.GetFileNameWithoutExtension(currentSelectedFile));
                        isZipFile = true;

                        if (Directory.Exists(videoFolder))
                        {
                            try
                            {
                                Directory.Delete(videoFolder, true);
                                UpdateDownloadResponse(Messages.GetMessage("VR-110006"), downloadError);
                            }
                            catch (Exception ex)
                            {
                                UpdateDownloadResponse(Messages.GetMessage("VR-110013"), downloadError);
                            }
                        }
                    }
                }

                if (!isZipFile)
                {
                    if (DownloadManagerCommon.DeleteFile(currentSelectedFile))
                    {
                        UpdateButtonResponse(grpboxStartDownload);
                        UpdateDownloadResponse(Messages.GetMessage("VR-110006"), downloadError);
                    }
                    else
                        UpdateDownloadResponse(Messages.GetMessage("VR-110013"), downloadError);
                }

                UpdateDownloadProgressBarResponse(0);

            }
        }

        /// <summary> 
        ///  This starts to download file
        ///  Triplet combines the three related objects in single instance
        /// </summary>
        private void DownloadFile(object triplet)
        {
            string guid = (triplet as Triplet).First.ToString();
            string path = (triplet as Triplet).Second.ToString();
            long offset = Int64.Parse((triplet as Triplet).Third.ToString());

            FileTransferDownload ftd = new FileTransferDownload();
            if (ftd.GetValidateFileSize(path))
            {
                UpdateDownloadResponse(Messages.GetMessage("VR-110004"), downloadError);
                return;
            }

            ftd.Guid = guid;
            ftd.ChunkSize = chunkSettingSize * 1024;

            // set the remote file name and start the background worker
            ftd.RemoteFileName = Path.GetFileName(path);

            if (String.IsNullOrEmpty(downloaFileLocation))
                ftd.LocalSaveFolder = Application.StartupPath;	// by default download the file in the application folder if download location is not defined
            else
                ftd.LocalSaveFolder = downloaFileLocation;

            ftd.ProgressChanged += new ProgressChangedEventHandler(ft_ProgressChanged);
            ftd.RunWorkerCompleted += new RunWorkerCompletedEventHandler(ft_RunWorkerCompleted);
            ftd.RunWorkerSync(new DoWorkEventArgs(offset));
        }

        /// <summary> 
        ///  The background worker process progress change event
        /// </summary>
        private void ft_ProgressChanged(object sender, ProgressChangedEventArgs e)
        {
            if (LoginInfo.UserID == string.Empty)
                (sender as FileTransferBase).CancelAsync();

            string fileName = ((FileTransferDownload)((sender as FileTransferBase))).RemoteFileName;

            if (currentThreadFile == fileName)
            {
                //if ( Convert.ToString(e.ProgressPercentage) == "0" )
                //    UpdateDownloadProgressResponse(e.UserState.ToString());
                //else
                UpdateDownloadProgressResponse(e.UserState.ToString());
                UpdateDownloadProgressBarResponse(e.ProgressPercentage);

                if (downloadStatus == "DownloadPaused")
                {
                    (sender as FileTransferBase).isPaused = true;
                    (sender as FileTransferBase).CancelAsync();
                }
                else if (downloadStatus == "DownloadDelete")
                {
                    (sender as FileTransferBase).isDeleted = true;

                    UpdateDownloadResponse(Messages.GetMessage("VR-110002"), downloadError);
                    UpdateButtonResponse(grpboxStartDownload);
                    UpdateDownloadingStatusMessage(fileName);
                }
                else if (downloadStatus == string.Empty)
                {
                    UpdateDownloadResponse(Messages.GetMessage("VR-110005"), downloadWIP);
                }
            }

        }

        /// <summary> 
        ///  The background worker process completed
        /// </summary>
        private void ft_RunWorkerCompleted(object sender, RunWorkerCompletedEventArgs e)
        {
            string guid = (sender as FileTransferBase).Guid;
            string fileName = ((FileTransferDownload)((sender as FileTransferBase))).RemoteFileName;

            if (e.Error != null)
            {
                UpdateDownloadResponse("Error has been occured during " + " file downloading process!", downloadError);
            }
            else if (e.Cancelled && (sender as FileTransferBase).isDeleted != true)
            {
                UpdateDownloadResponse(Messages.GetMessage("VR-110000"), downloadError);
                UpdateDownloadProgressBarResponse(0);
            }
            else if ((sender as FileTransferBase).isPaused)
            {
                UpdateDownloadResponse(Messages.GetMessage("VR-110001"), downloadWIP);
            }
            else if ((sender as FileTransferBase).isDeleted)
            {
                UpdateDownloadResponse(Messages.GetMessage("VR-110002"), downloadError);
                UpdateDownloadProgressBarResponse(0);
            }
            else if ((sender as FileTransferBase).isError)
            {
                UpdateDownloadResponse(Messages.GetMessage("VR-110012"), downloadError);
                UpdateDownloadProgressBarResponse(0);
                UpdateButtonResponse(grpboxResume);
            }
            else
            {
                try
                {
                    //For Zip dowload
                    if ((sender as FileTransferBase).RemoteFileExtension.Equals(".zip"))
                    {
                        string localFilePath = (sender as FileTransferBase).LocalFilePath;
                        string zipFileName = localFilePath + (sender as FileTransferBase).RemoteFileExtension;
                        File.Move((sender as FileTransferBase).LocalFilePath, zipFileName);
                        using (ZipFile zip = ZipFile.Read(zipFileName))
                        {
                            foreach (ZipEntry ze in zip)
                            {
                                ze.Extract(DownloadManagerCommon.GetRepositoryLocation(), ExtractExistingFileAction.OverwriteSilently);
                            }
                        }

                        File.Delete(zipFileName);
                    }
                    else
                    {
                        // For File Download
                        File.Move((sender as FileTransferBase).LocalFilePath, (sender as FileTransferBase).LocalFilePath + (sender as FileTransferBase).RemoteFileExtension);
                    }
                    UpdateDownloadResponse(Messages.GetMessage("VR-110003"), downloadDone);

                    if (currentThreadFile == fileName)
                        UpdateButtonResponse(grpboxDownloadComplete);

                }
                catch (Exception ex)
                {
                }
            }
        }

        /// <summary> 
        ///  This updates the downloading status message
        /// </summary>
        private void UpdateDownloadingStatusMessage(string fileName)
        {
            long totalFileSize = WebService.GetFileSize(fileName);
            UpdateDownloadProgressResponse(String.Format("Video Size: {0} ", FileTransferBase.CalcFileSize(totalFileSize)));
        }

        /// <summary> 
        ///  This delegates shows downloading file progress bar
        /// </summary>
        private void UpdateDownloadProgressBarResponse(int downloadProgress)
        {
            if (grpboxResume.Visible == true && downloadStatus != downloadPause)
                UpdateButtonResponse(grpboxPaused);

            if (progressBarDownload.InvokeRequired)
            {
                updateProgressBarDelegate delegateProgress = new updateProgressBarDelegate(UpdateDownloadProgressBarResponse);
                progressBarDownload.Invoke(delegateProgress, new object[] { downloadProgress });
            }
            else
                progressBarDownload.Value = downloadProgress;

        }

        /// <summary> 
        ///  This delegates shows downloading file progress details
        /// </summary>
        private void UpdateDownloadProgressResponse(string downloadProgress)
        {
            if (lblFileSizeDownload.InvokeRequired)
            {
                updateProgressDelegate delegateProgress = new updateProgressDelegate(UpdateDownloadProgressResponse);
                lblFileSizeDownload.Invoke(delegateProgress, new object[] { downloadProgress });
            }
            else
                lblFileSizeDownload.Text = downloadProgress;
        }

        /// <summary> 
        ///  This delegates shows download progress status
        /// </summary>
        private void UpdateDownloadResponse(string response, string messagecolor)
        {
            string filename = Path.GetFileNameWithoutExtension(response);

            if (lblStatus.InvokeRequired)
            {
                updateResponseDelegate delegateSDM = new updateResponseDelegate(UpdateDownloadResponse);
                lblStatus.Invoke(delegateSDM, new object[] { response, messagecolor });
            }
            else
                lblStatus.Text = response;

            if (messagecolor != string.Empty)
            {
                Color messageForeColor = System.Drawing.ColorTranslator.FromHtml(messagecolor);
                lblStatus.ForeColor = messageForeColor;
            }
        }

        /// <summary> 
        ///  This delegates shows the buttons according to download progress 
        /// </summary>
        private void UpdateButtonResponse(Panel currentStateButton)
        {
            HideButtons();

            if (currentStateButton.InvokeRequired)
            {
                updateButtonDelegate delegateButton = new updateButtonDelegate(UpdateButtonResponse);
                currentStateButton.Invoke(delegateButton, new object[] { currentStateButton });
            }
            else
            {
                btnDownload.Visible = true;
                currentStateButton.Visible = true;
            }
        }

        /// <summary> 
        ///  This hides all the buttons
        /// </summary>
        private void HideButtons()
        {
            try
            {
                btnDownload.Visible = false;
                grpboxResume.Visible = false;
                grpboxPaused.Visible = false;
                grpboxDownloadComplete.Visible = false;
                grpboxStartDownload.Visible = false;
            }
            catch (Exception ex)
            {
            }
        }

        /// <summary> 
        ///  This creates new thread for download file
        /// </summary>
        private void CreateDownloadThread(long offset)
        {
            if (this.lstDownloadFiles.SelectedItems.Count == 0)
                return;

            foreach (ListViewItem item in this.lstDownloadFiles.SelectedItems)
            {
                string guid = Guid.NewGuid().ToString();
                ThreadPool.QueueUserWorkItem(new WaitCallback(this.DownloadFile), new Triplet(guid, item.Text, offset));
            }
        }

        /// <summary> 
        ///  This builds available video files list
        /// </summary>
        private void BindDownloadFileList()
        {

            //System.Net.ServicePointManager.Expect100Continue = false;
            //List<string> lstVideoFiles = WebService.GetFilesList();

            if (LoginInfo.lstVideoFiles != null)
            {
                foreach (string file in LoginInfo.lstVideoFiles)
                {
                    this.lstDownloadFiles.Items.Add(file);
                }

                SetToolTips();
            }


            ////lblFileSizeDownload.Dispose();
            ////progressBarDownload.Dispose();
        }

        /// <summary> 
        ///  Get the currently selected file from the download video list
        /// </summary>
        private string GetSelectedFile()
        {
            int numberOfItems = this.lstDownloadFiles.SelectedItems.Count;
            string fileName = string.Empty;

            if (numberOfItems == 1)
            {
                fileName = this.lstDownloadFiles.SelectedItems[0].Text;
            }

            return fileName;
        }

        /// <summary>
        /// Sets the tool tips.
        /// </summary>
        /// <remarks>This allocates tooltips for the form controls</remarks>
        private void SetToolTips()
        {
            // Create the ToolTip and associate with the Form container.
            ToolTip screenTooltip = new ToolTip();

            // Set up the delays for the ToolTip.
            screenTooltip.AutoPopDelay = 2000;
            screenTooltip.InitialDelay = 1000;
            screenTooltip.ReshowDelay = 500;

            // Force the ToolTip text to be displayed whether or not the form is active.
            screenTooltip.ShowAlways = true;
            screenTooltip.IsBalloon = true;

            // Set up the ToolTip text for form controls
            screenTooltip.SetToolTip(this.btnDownload, "Click to start downloading");
            screenTooltip.SetToolTip(this.btnDeleteDownloaded, "Click to delete video");
            screenTooltip.SetToolTip(this.btnStatus, "File downloaded succesfully!");
            screenTooltip.SetToolTip(this.btnPause, "Click to pause downloading");
            screenTooltip.SetToolTip(this.btnResume, "Click to resume download process");
            screenTooltip.SetToolTip(this.btnDelete, "Click to delete video");
            screenTooltip.SetToolTip(this.btnCancel, "Click to cancel downloading");
        }

        /// <summary>
        /// Gets the videos.
        /// </summary>
        private void GetVideos()
        {
            MtomWebService.MTOMSoapClient WebService = new MtomWebService.MTOMSoapClient();
            System.Net.ServicePointManager.Expect100Continue = false;

            try
            {
                LoginInfo.lstVideoFiles = WebService.GetFilesList();
            }
            catch (Exception ex)
            {
                LoginInfo.lstVideoFiles = null;
                MessageBox.Show("Unable to connect to the server. Please check net connection.\r\n", " Download Video ", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        #endregion
    }
}
