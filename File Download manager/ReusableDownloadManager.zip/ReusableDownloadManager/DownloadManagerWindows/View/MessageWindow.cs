﻿//@filename: MessageWindow.cs
//@description: Class contains functionalities for displaying message dialogue. 
// Functionality includes: 1) Displays message dialogue.
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, VirtualRunner
//@version: V 1.0.0 Created on 03/21/2011 
//@created by Kiran Vidhate

using System;
using System.Drawing;
using System.Windows.Forms;
using System.Drawing.Drawing2D;
using DownloadManager.Common;

/// <summary>
///   This is View classes namespace.
/// </summary>
namespace DownloadManager.View
{
    /// <summary>
    /// Class contains functionalities for displaying message dialogue. 
    /// </summary>
    public partial class MessageWindow : Form
    {
        #region --Class Variables--
        public Timer _messageTimer;

        static MessageWindow _newMessageWindow;
        static Icon _messagePictureBGImage;

        static string _dialogueResult;
        static string _btnOkLable;
        static string _btnCancelLable;

        static bool _isDisplayed = false;
        static bool _enableTimer = false;
        static bool _showOkOnly = true;

        int _disposeFormTimer;
        #endregion

        #region --Class Contstructor--
        /// <summary>
        /// Initializes a new instance of the <see cref="MessageWindow"/> class.
        /// </summary>
        public MessageWindow()
        {
            InitializeComponent();
        }
        #endregion

        #region --Class Public Methods--
        /// <summary>
        /// Shows the message box.
        /// </summary>
        /// <param name="txtMessage">The message details.</param>
        /// <returns></returns>
        public static string Show(string txtMessage)
        {
            if (!_isDisplayed)
            {
                SetDialogButtons(MessageBoxButtons.OK);

                _isDisplayed = true;
                _newMessageWindow = new MessageWindow();
                _newMessageWindow.lblTitle.Text = Application.ProductName;
                _newMessageWindow.lblMessage.Text = txtMessage;
               // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Information;
                _newMessageWindow.StartPosition = FormStartPosition.CenterScreen;
                _newMessageWindow.ShowDialog();
              
            }

            return _dialogueResult;
        }

        /// <summary>
        /// Shows the message box.
        /// </summary>
        /// <param name="txtMessage">The message details.</param>
        /// <param name="txtTitle">The message title.</param>
        /// <returns></returns>
        public static string Show(string txtMessage, string txtTitle)
        {
            if (!_isDisplayed)
            {
                SetDialogButtons(MessageBoxButtons.OK);

                _isDisplayed = true;
                _newMessageWindow = new MessageWindow();
                _newMessageWindow.lblTitle.Text = txtTitle;
                _newMessageWindow.lblMessage.Text = txtMessage;
               // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Information;
                _newMessageWindow.StartPosition = FormStartPosition.CenterScreen;
                _newMessageWindow.ShowDialog();
            }

            return _dialogueResult;
        }

        /// <summary>
        /// Shows the specified TXT message.
        /// </summary>
        /// <param name="txtMessage">The TXT message.</param>
        /// <param name="txtTitle">The TXT title.</param>
        /// <param name="messageBoxButtons">The message box buttons.</param>
        /// <returns></returns>
        public static string Show(string txtMessage, string txtTitle, MessageBoxButtons messageBoxButtons)
        {
            if (!_isDisplayed)
            {
                SetDialogButtons(messageBoxButtons);

                _isDisplayed = true;
                _newMessageWindow = new MessageWindow();
                _newMessageWindow.lblTitle.Text = txtTitle;
                _newMessageWindow.lblMessage.Text = txtMessage;
               // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Information;
                _newMessageWindow.StartPosition = FormStartPosition.CenterScreen;
                _newMessageWindow.ShowDialog();
            }

            return _dialogueResult;
        }

        /// <summary>
        /// Shows the message box.
        /// </summary>
        /// <param name="txtMessage">The message details.</param>
        /// <param name="txtTitle">The message title.</param>
        /// <param name="autoClose">if set to <c>true</c> [auto close message box].</param>
        /// <returns></returns>
        public static string Show(string txtMessage, string txtTitle, bool autoClose)
        {
            if (!_isDisplayed)
            {
                _enableTimer = autoClose;
                _isDisplayed = true;
                _newMessageWindow = new MessageWindow();
                _newMessageWindow.lblTitle.Text = txtTitle;
                _newMessageWindow.lblMessage.Text = txtMessage;
                //_messagePictureBGImage = global::VirtualRunner.Properties.Resources.Information;
                _newMessageWindow.StartPosition = FormStartPosition.CenterScreen;
                _newMessageWindow.ShowDialog();
            }

            return _dialogueResult;
        }

        /// <summary>
        /// Shows the specified TXT message.
        /// </summary>
        /// <param name="txtMessage">The message details.</param>
        /// <param name="txtTitle">The message title.</param>
        /// <param name="messageBoxButtons">The message box buttons.</param>
        /// <param name="messageBoxIcon">The message box icon.</param>
        /// <returns></returns>
        public static string Show(string txtMessage, string txtTitle, MessageBoxButtons messageBoxButtons, MessageBoxIcon messageBoxIcon)
        {
            if (!_isDisplayed)
            {
                SetDialogButtons(messageBoxButtons);
                SetDialogueIcon(messageBoxIcon);

                _isDisplayed = true;
                _newMessageWindow = new MessageWindow();
                _newMessageWindow.lblTitle.Text = txtTitle;
                _newMessageWindow.lblMessage.Text = txtMessage;
                _newMessageWindow.StartPosition = FormStartPosition.CenterScreen;
                _newMessageWindow.ShowDialog();
            }

            return _dialogueResult;
        }

        #endregion

        #region --Form Events--
        /// <summary>
        /// Handles the Load event of the MessageWindow control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void MessageWindow_Load(object sender, EventArgs e)
        {
            SetMessageBoxTimer();
            SetControlsProperties();
        }

        /// <summary>
        /// Handles the Paint event of the MessageWindow control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.Windows.Forms.PaintEventArgs"/> instance containing the event data.</param>
        private void MessageWindow_Paint(object sender, PaintEventArgs e)
        {
            Graphics messageBoxGraphics = e.Graphics;
            Pen penDrawMessageBox = new Pen(Color.FromArgb(0, 0, 0), 1);
            Rectangle messageBoxArea = new Rectangle(0, 0, this.Width - 1, this.Height - 1);
            LinearGradientBrush linearGradientBrush = new LinearGradientBrush(messageBoxArea, Color.FromArgb(0, 0, 0), Color.FromArgb(0, 0, 0), LinearGradientMode.Vertical);
            messageBoxGraphics.FillRectangle(linearGradientBrush, messageBoxArea);
            messageBoxGraphics.DrawRectangle(penDrawMessageBox, messageBoxArea);
        }

        /// <summary>
        /// Handles the Click event of the btnOK control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnOK_Click(object sender, EventArgs e)
        {
            if (_enableTimer)
            {
                _newMessageWindow._messageTimer.Stop();
                _newMessageWindow._messageTimer.Dispose();
            }

            _dialogueResult = Enumerations.MessageStatus.Accepted.ToString();
            _isDisplayed = false;
            _newMessageWindow.Dispose();
        }

        /// <summary>
        /// Handles the Click event of the btnCancel control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void btnCancel_Click(object sender, EventArgs e)
        {
            if (_enableTimer)
            {
                _newMessageWindow._messageTimer.Stop();
                _newMessageWindow._messageTimer.Dispose();
            }

            _dialogueResult = Enumerations.MessageStatus.Rejected.ToString();
            _isDisplayed = false;
            _newMessageWindow.Dispose();
        }

        /// <summary>
        /// Handles the tick event of the timer control.
        /// </summary>
        /// <param name="sender">The source of the event.</param>
        /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
        private void timer_tick(object sender, EventArgs e)
        {
            _disposeFormTimer--;

            if (_disposeFormTimer >= 0)
            {
                _newMessageWindow.lblTimer.Text = _disposeFormTimer.ToString();
            }
            else
            {
                _dialogueResult = Enumerations.MessageStatus.Rejected.ToString();
                if (_enableTimer)
                {
                    _newMessageWindow._messageTimer.Stop();
                    _newMessageWindow._messageTimer.Dispose();
                }
                _isDisplayed = false;
                _newMessageWindow.Dispose();
            }
        }
        #endregion

        #region --Private Methods--
        /// <summary>
        /// Sets the message box timer.
        /// </summary>
        private void SetMessageBoxTimer()
        {
            if (_enableTimer)
            {
                _disposeFormTimer = 30;
                _newMessageWindow.lblTimer.Text = _disposeFormTimer.ToString();
                _messageTimer = new Timer();
                _messageTimer.Interval = 1000;
                _messageTimer.Enabled = true;
                _messageTimer.Start();
                _messageTimer.Tick += new System.EventHandler(this.timer_tick);
            }
        }

        /// <summary>
        /// Sets the dialog buttons.
        /// </summary>
        /// <param name="messageBoxButtons">The message box buttons.</param>
        private static void SetDialogButtons(MessageBoxButtons messageBoxButtons)
        {
            switch (messageBoxButtons)
            {
                case MessageBoxButtons.YesNo:
                    _btnOkLable = Messages.GetMessage("VR-90005");
                    _btnCancelLable = Messages.GetMessage("VR-90006");
                    _showOkOnly = false;
                    break;
                case MessageBoxButtons.OKCancel:
                    _btnOkLable = Messages.GetMessage("VR-90003");
                    _btnCancelLable = Messages.GetMessage("VR-90004");
                    break;
                default:
                    _btnOkLable = Messages.GetMessage("VR-90003");
                    _showOkOnly = true;
                    break;
            }
        }

        /// <summary>
        /// Sets the dialogue icon.
        /// </summary>
        /// <param name="messageBoxIcon">The message box icon.</param>
        private static void SetDialogueIcon(MessageBoxIcon messageBoxIcon)
        {
            switch (messageBoxIcon)
            {
                case MessageBoxIcon.Error:
                    //_messagePictureBGImage = global::VirtualRunner.Properties.Resources.Error;
                    break;
                case MessageBoxIcon.Question:
                   // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Question;
                    break;
                case MessageBoxIcon.Asterisk:
                   // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Success;
                    break;
                default:
                   // _messagePictureBGImage = global::VirtualRunner.Properties.Resources.Information;
                    break;
            }
        }

        /// <summary>
        /// Sets the message box controls properties.
        /// </summary>
        private void SetControlsProperties()
        {
            btnOk.Text = _btnOkLable;
            if (_showOkOnly)
            {
                btnCancel.Visible = false;
                btnOk.Left = (this.ClientSize.Width - btnOk.Width) / 2;
            }
            else
            {
                btnCancel.Visible = true;
                btnCancel.Text = _btnCancelLable;
            }

           // Image imageIcon = new Bitmap(_messagePictureBGImage.ToBitmap(), 38, 38);
        }
        #endregion
    }
}
