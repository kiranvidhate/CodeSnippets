﻿//@filename: MessageControl.cs
//
//@description: Set Message on each form
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using DownloadManager.Common;

/// <summary>
///  This is UserControls classes namespace 
/// </summary>
namespace DownloadManager.UserControls
{

    /// <summary>
    /// This is MessageControl class. It performs application to set message on screen
    /// </summary>
    /// <remarks></remarks>
    public partial class MessageControl : UserControl
    {

        #region Global Declaration
        #endregion

        #region Form Events

        public MessageControl()
        {
            InitializeComponent();
        }

        #endregion

        #region Supportive Functions
        
        /// <summary>
        /// Sets the image icon.
        /// </summary>
        /// <param name="status">The status.</param>
        /// <remarks></remarks>
        public void SetImageIcon(int status, string messageString)
        {
            if (status == 0)
            {
                lblMessage.ForeColor = Color.Red;
            }
            else
            {
                lblMessage.ForeColor = Color.Green;
            }
            lblMessage.Text = messageString;
        }

        #endregion
    }
}
