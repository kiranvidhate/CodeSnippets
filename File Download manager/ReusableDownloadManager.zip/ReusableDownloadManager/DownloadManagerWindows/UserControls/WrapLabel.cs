﻿//@filename: WrapLabel.cs
//@description: Class contains an user control to generate custom lable with wrap text funcitonality. 
// Functionality includes: 1) Transperent custom lable with wrap text funcitonality.
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 09/19/2011  

using System;
using System.Text;
using System.Drawing;
using System.Windows.Forms;

/// <summary>
///  This is UserControls classes namespace 
/// </summary>
namespace DownloadManagers.UserControls
{
    /// <summary>
    /// Class contains an user control to generate custom lable with wrap text funcitonality. 
    /// </summary>
    class WrapLabel : Label
    {
        #region -- Class Variables--
        private bool _isWrapping;
        #endregion

        #region -- Class Constructor--
        /// <summary>
        /// Initializes a new instance of the <see cref="WrapLabel"/> class.
        /// </summary>
        public WrapLabel()
        {
            this.AutoSize = false;
        }
        #endregion

        #region -- Class Private Methods--
        /// <summary>
        /// Resizes the label.
        /// </summary>
        private void resizeLabel()
        {
            if (_isWrapping) return;
            try
            {
                _isWrapping = true;
                Size size = new Size(this.Width, Int32.MaxValue);
                size = TextRenderer.MeasureText(this.Text, this.Font, size, TextFormatFlags.WordBreak);
                this.Height = size.Height;
            }
            finally
            {
                _isWrapping = false;
            }
        }
        #endregion

        #region -- Class Protected overridden Methods--
        /// <summary>
        /// Overrides Label controls OnTextChanged event
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
        protected override void OnTextChanged(EventArgs e)
        {
            base.OnTextChanged(e);
            resizeLabel();
        }

        /// <summary>
        /// Overrides Label controls OnFontChanged event
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
        protected override void OnFontChanged(EventArgs e)
        {
            base.OnFontChanged(e);
            resizeLabel();
        }

        /// <summary>
        /// Raises the <see cref="E:System.Windows.Forms.Control.SizeChanged"/> event.
        /// </summary>
        /// <param name="e">An <see cref="T:System.EventArgs"/> that contains the event data.</param>
        protected override void OnSizeChanged(EventArgs e)
        {
            base.OnSizeChanged(e);
            resizeLabel();
        }
        #endregion
    }
}
