﻿document.getElementById("logo").href = "#";
document.getElementsByClassName("logo__title")[0].innerHTML = "My API Project";
