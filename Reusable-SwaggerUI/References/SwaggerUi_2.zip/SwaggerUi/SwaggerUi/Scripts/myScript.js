﻿$(document).ready(function () {
    alert("Hello from custom JavaScript file.");
});