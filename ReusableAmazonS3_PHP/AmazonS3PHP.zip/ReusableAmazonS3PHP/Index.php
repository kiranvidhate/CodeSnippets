<?php
/**
* Amazon S3 PHP demo page
*
* @description this file demonstrates the usage of available methods in the Amazon S3 helper
* @author Kiran Vidhate
* @created 25-Jun-2012
*/

	if (!class_exists('S3')) require_once 'S3.php';
  $results = '';

	// Handles form submission request
	if($_REQUEST) {
		// AWS access info
		if (!defined('awsAccessKey')) define('awsAccessKey', 'KEY-HERE');
		if (!defined('awsSecretKey')) define('awsSecretKey', 'KEY-HERE');
	
		// Instantiate the class
		$s3 = new S3(awsAccessKey, awsSecretKey);//, false, 's3-website-eu-west-1.amazonaws.com');
		
		// SAmple Bucket Name
		$bucketName = "TestBucket0905";
		$uploadFile = '';
		
		$txtFileToDownload = $_REQUEST['txtFileToDownload'];
		
		if (!$_FILES["fileUploadControl"]["error"] > 0) {
			$uploadFile = $_FILES["fileUploadControl"]["name"];
		} 
		
		// List all buckets
		if ($_REQUEST['hdnAction'] ==  'ListBuckets') {
		 $results =  "<br/><b>Buckets:</b><br/>".print_r($s3->listBuckets(), 1)."\n";
		}
		
		// Creates new bucket with teh default name
		if ($_REQUEST['hdnAction'] ==  'CreateBuckets') {
			//Create Bucket
			if ($s3->putBucket($bucketName, S3::ACL_PUBLIC_READ_WRITE)) {
				$results =  "Created bucket {$bucketName}".PHP_EOL;
			} else {
				$results =  "Error creating bucket {$bucketName}".PHP_EOL;
			}
		}
		
		// Uploads a file to bucket
		if ($_REQUEST['hdnAction'] ==  'UploadFile') {
			// Put our file (also with public read access)
			if ($s3->uploadObject($uploadFile, $bucketName, baseName($uploadFile), S3::ACL_PUBLIC_READ_WRITE)) {
				$results =  "File copied to {$bucketName}/".baseName($uploadFile).PHP_EOL;
			} else {
				$results = "Error uploading file";
			}
		}
		
		// Downloads file from bucket
		if ($_REQUEST['hdnAction'] ==  'DownloadFile') {
			//savefile
			 $s3->getObject($bucketName, $txtFileToDownload, $txtFileToDownload);
			 $results = "File has been copied to the applicaiton root folder";
		}
		
		// Delete file from bucket
		if ($_REQUEST['hdnAction'] ==  'DeleteObject') {
			// Delete our file
			if ($s3->deleteObject($bucketName, $txtFileToDownload)) {
				$results = "Deleted file $txtFileToDownload\n";
			} else {
				$results = "Error deleting file";
			}
		}
		
		// List files in the bucket
		if ($_REQUEST['hdnAction'] ==  'ListObjects') {
			// Get the contents of our bucket
			$contents = $s3->getBucket($bucketName);
			$results = "Files in bucket {$bucketName}: ". print_r($contents, 1);
		}
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<title>Home page</title>
<meta http-equiv="content-type" content="text/html; charset=utf-8" />
<meta http-equiv="content-language" content="" />
<link href="assets/css/style.css" rel="stylesheet" type="text/css" />
<style>
.button {
	border: 1px solid #006;
	background: #ccc;
	padding:2px;
}
.button:hover {
	border: 1px solid #f00;
	background: #eef;
}
</style>
</head>
<body style="font-family: Verdana; font-size: 12px;">
<form id="form1" method="post" action="<?php echo $_SERVER['PHP_SELF']; ?>" enctype="multipart/form-data">
  <div id="mainDiv">
    <div id="divHeader">
      <div id="divLogo">
        <h1> Amazon S3 PHP Reusable API Demo </h1>
      </div>
    </div>
    <div id="divMain">
      <div id="divMain2">
        <div id="divContent">
          <p> <br />
            Amazon S3 is storage for the Internet. It is designed to make web-scale computing
            easier for developers. Amazon S3 provides a simple web services interface that can
            be used to store and retrieve any amount of data, at any time, from anywhere on
            the web. It gives any developer access to the same highly scalable, reliable, secure,
            fast, inexpensive infrastructure that Amazon uses to run its own global network
            of web sites. The service aims to maximize benefits of scale and to pass those benefits
            on to developers. </p>
          <br />
          <table width="100%" cellpadding="5" cellspacing="5">
            <tr>
              <td colspan="2"><h3> Click on desired option to see the results: </h3></td>
            </tr>
            <tr>
              <td> List Buckets: </td>
              <input type="hidden" id="hdnAction" name="hdnAction" value=""/>
              <td><input id="btnListBuckets" type="submit" value="List Buckets" class="button"  onclick="document.getElementById('hdnAction').value = 'ListBuckets'"/></td>
            </tr>
            <tr>
              <td> Create Bucket: </td>
              <td><input id="btnCreateBuckets" type="submit" value="Create Buckets" class="button" onclick="document.getElementById('hdnAction').value = 'CreateBuckets'" />
                <span>&nbsp;&nbsp;&nbsp;Creates sample bucket as "TestBucket0905"</span></td>
            </tr>
            <tr>
              <td> Upload File: </td>
              <td><input id="fileUploadControl" name="fileUploadControl" type="file" />
                <input id="btnUploadFile" type="submit" value="Upload File" class="button" onclick="document.getElementById('hdnAction').value = 'UploadFile'"/></td>
            </tr>
            <tr>
              <td> Download/Delete File: </td>
              <td><input id="txtFileToDownload" name="txtFileToDownload" type="text" />
                <input id="btnDownloadFile" type="submit" value="Download File" class="button" onclick="document.getElementById('hdnAction').value = 'DownloadFile'"/>
                <input id="btnDeleteObject" type="submit" value="Delete Object" class="button" onclick="document.getElementById('hdnAction').value = 'DeleteObject'"/></td>
            </tr>
            <tr>
              <td> List Object: </td>
              <td><input id="btnListObjects" type="submit" value="List Objects" class="button" onclick="document.getElementById('hdnAction').value = 'ListObjects'"/></td>
            </tr>
          </table>
          <br />
          <table width="100%" cellpadding="5" cellspacing="5">
            <tr>
              <td colspan="4"><strong>Rssults:</strong></td>
            </tr>
            <tr>
              <td colspan="4">&nbsp;</td>
            </tr>
            <tr>
              <td colspan="4"><?php echo $results; ?></td>
            </tr>
          </table>
        </div>
      </div>
    </div>
  </div>
</form>
</body>
</html>