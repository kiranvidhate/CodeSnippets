//@filename: GoogleMap.ascx.cs
//
//@description: This class is teh user control for google map.  
//
//
//@aboutauthor: Aress Softwares
//@copyright: Copyright (C) 2011, Code Snippet
//@version: V 1.0.0 Created on 10/22/2011  

using System;
using System.Web.UI;

/// <summary>
/// This class is teh user control for google map.  
/// </summary>
public partial class GoogleMap : System.Web.UI.UserControl
{
    #region --Control Properties--

    GoogleObject _googlemapobject = new GoogleObject();

    /// <summary>
    /// Gets or sets the google map object.
    /// </summary>
    /// <value>
    /// The google map object.
    /// </value>
    public GoogleObject Map
    {
        get { return _googlemapobject; }
        set { _googlemapobject = value; }
    }

    bool _showcontrols = false;
    /// <summary>
    /// Gets or sets a value indicating whether [show controls].
    /// </summary>
    /// <value>
    ///   <c>true</c> if [show controls]; otherwise, <c>false</c>.
    /// </value>
    public bool ShowControls
    {
        get { return _showcontrols; }
        set { _showcontrols = value; }
    }
    #endregion

    #region -- Control Events--
    /// <summary>
    /// Handles the Load event of the Page control.
    /// </summary>
    /// <param name="sender">The source of the event.</param>
    /// <param name="e">The <see cref="System.EventArgs"/> instance containing the event data.</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!IsPostBack)
        {
            Session["GOOGLE_MAP_OBJECT"] = Map;
        }
        else
        {
            Map = (GoogleObject)Session["GOOGLE_MAP_OBJECT"];

            if (Map == null)
            {
                Map = new GoogleObject();
                Session["GOOGLE_MAP_OBJECT"] = Map;
            }
        }

        string sScript = "<script src='http://maps.google.com/maps?file=api&amp;v=" + Map.APIVersion + ">&amp;key=" + Map.APIKey + "'  type='text/javascript'></script>";
        sScript += "<script type='text/javascript' src='UserControls/GoogleMapControl/JS/GoogleMapAPIWrapper.js'></script>";
        sScript += "<script language='javascript'> if (window.DrawGoogleMap) { DrawGoogleMap(); } </script>";
        Page.ClientScript.RegisterStartupScript(Page.GetType(), "onLoadCall", sScript);
    }

    #endregion
}
