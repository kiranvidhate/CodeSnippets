﻿using System;
using System.Data;

public partial class _Default : System.Web.UI.Page
{
    DataTable _GooglePoints;
    protected void Page_Load(object sender, EventArgs e)
    {
        Google.Map.Width = "800px";
        Google.Map.Height = "500px";

        //Specify initial Zoom level Max 20.
        Google.Map.ZoomLevel = 14;

        //Specify Center Point for map. Map will be centered on this point.
       // Google.Map.CenterPoint = new GooglePoint("1", 43.66619, -79.44268);

        _GooglePoints = GetMapPoints();

        // Loop over the rows.
        foreach (DataRow row in _GooglePoints.Rows) 
        {
            GooglePoint googleMapPoint = new GooglePoint();
            googleMapPoint.ID =row.ItemArray[0].ToString();
            googleMapPoint.Latitude =Convert.ToDouble(row.ItemArray[1]);
            googleMapPoint.Longitude = Convert.ToDouble(row.ItemArray[2]);

            if (!string.IsNullOrEmpty(row.ItemArray[3].ToString()))
            {
                googleMapPoint.IconImage = row.ItemArray[3].ToString();
            }

            if (!string.IsNullOrEmpty(row.ItemArray[4].ToString()))
            {
                googleMapPoint.InfoHTML = row.ItemArray[4].ToString();
            }

            Google.Map.Points.Add(googleMapPoint);
        }
    }

    /// <summary>
    /// Gets the map points.
    /// </summary>
    /// <returns></returns>
    private DataTable GetMapPoints()
    {
        DataTable GooglePoints = new DataTable();
        GooglePoints.Columns.Add("ID", typeof(int));
        GooglePoints.Columns.Add("Lat", typeof(double));
        GooglePoints.Columns.Add("Long", typeof(double));
        GooglePoints.Columns.Add("Image", typeof(string));
        GooglePoints.Columns.Add("HTML", typeof(string));

        //
        // Here we add five DataRows.
        //
        GooglePoints.Rows.Add(1, 43.65669, -79.45278, string.Empty, string.Empty);
        GooglePoints.Rows.Add(2, 43.66619, -79.44268, string.Empty, string.Empty);
        GooglePoints.Rows.Add(3, 43.67689, -79.43270, string.Empty, string.Empty);
        GooglePoints.Rows.Add(4, 43.65669, -79.43270, "Images/sun.png", "<b>Kiran vidhate</b><br/><a href='http://google.com' target='_blank'>Click Here</a>");

        return GooglePoints;
    }
}