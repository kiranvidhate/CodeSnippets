﻿Imports System.Web
Imports System.Web.Services
Imports System.Web.Services.Protocols
Imports Controller.ZipCodeFinder.Cities

<WebService(Namespace:="http://jqdemo.com/")> _
<WebServiceBinding(ConformsTo:=WsiProfiles.BasicProfile1_1)> _
<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Public Class WSCities
    Inherits System.Web.Services.WebService

#Region "Public Methods"

    ''' <summary>
    ''' Finds the zip codes in radius.
    ''' </summary>
    ''' <param name="objCity">The obj city.</param><returns></returns>
    <SoapHeader("ZipFinder")> _
    <WebMethod()> _
    Public Function FindZipCodesInRadius(ByVal objCity As Model.ZipCodeFinder.City) As Generic.List(Of Model.ZipCodeFinder.City)
        Dim objCitiesController As New Controller.ZipCodeFinder.Cities
        Return objCitiesController.FindZipCodesInRadius(objCity)
    End Function

    ''' <summary>
    ''' Adds the city.
    ''' </summary>
    ''' <param name="objCity">The obj city.</param><returns></returns>
    <SoapHeader("ZipFinder")> _
    <WebMethod()> _
    Public Function AddCity(ByVal objCity As Model.ZipCodeFinder.City) As Integer
        Dim objCitiesController As New Controller.ZipCodeFinder.Cities
        Return objCitiesController.AddCity(objCity)
    End Function
#End Region

End Class