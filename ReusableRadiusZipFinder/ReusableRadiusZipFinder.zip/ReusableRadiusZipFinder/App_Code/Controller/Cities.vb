﻿Imports Microsoft.VisualBasic
Imports System.Linq
Imports System.Data
Imports System.IO
Imports DBOPS
Imports System.Net
Imports System.Xml

Namespace Controller.ZipCodeFinder
    Public Class Cities

#Region "General Declaration"
        Dim dal As New DBOPS.clsDBOperations
#End Region

#Region "Public Methods"
        ''' <summary>
        ''' Finds the zip codes in radius.
        ''' </summary>
        ''' <param name="objCity">The obj city.</param><returns></returns>
        Public Function FindZipCodesInRadius(ByVal objCity As Model.ZipCodeFinder.City) As Generic.List(Of Model.ZipCodeFinder.City)
            Dim lstCitiesList As New Generic.List(Of Model.ZipCodeFinder.City)
            Using objData As New DBOPS.clsDBOperations()

                Dim params As New Generic.List(Of Data.Common.DbParameter)

                params.Add(objData.createParameter("@BaseZipCode", objCity.YourZipCode))
                params.Add(objData.createParameter("@Radius", objCity.Radius))

                Using drCities As New DBOPS.SafeDataReader(objData.getSpReader("FindZipCodesInRadius", params.ToArray))
                    While drCities.Read()
                        lstCitiesList.Add(BuildCities(drCities, False, False))
                    End While
                End Using
            End Using

            Return lstCitiesList
        End Function

        ''' <summary>
        ''' Adds the city.
        ''' </summary>
        ''' <param name="objCity">The obj city.</param><returns></returns>
        Public Function AddCity(ByVal objCity As Model.ZipCodeFinder.City) As Integer
            Using objData As New DBOPS.clsDBOperations()

                Dim params As New Generic.List(Of Data.Common.DbParameter)

                GetLatLon(objCity)

                params.Add(objData.createParameter("@ZipCode", objCity.YourZipCode))
                params.Add(objData.createParameter("@City", objCity.YourCity))
                params.Add(objData.createParameter("@Latitude", objCity.YourCityLatitude))
                params.Add(objData.createParameter("@Longitude", objCity.YourCityLongitude))

                Using drCities As New DBOPS.SafeDataReader(objData.getSpReader("AddCity", params.ToArray))
                    drCities.Read()
                    Return drCities(0)
                End Using
            End Using
        End Function
#End Region

#Region "Private Methods"

        Private Sub GetLatLon(ByRef objCity As Model.ZipCodeFinder.City)

            Dim url = "http://maps.googleapis.com/maps/api/geocode/xml?address=" & HttpContext.Current.Server.UrlEncode(String.Concat(objCity.YourCity, ",", objCity.YourZipCode)) & "&sensor=false"

            Dim request = WebRequest.Create(url)
            Dim response = DirectCast(request.GetResponse(), HttpWebResponse)

            If response.StatusCode = HttpStatusCode.OK Then

                Dim ms = New MemoryStream()
                Dim responseStream = response.GetResponseStream()

                Dim buffer = New [Byte](2047) {}
                Dim count As Integer = responseStream.Read(buffer, 0, buffer.Length)

                While count > 0
                    ms.Write(buffer, 0, count)
                    count = responseStream.Read(buffer, 0, buffer.Length)
                End While

                responseStream.Close()
                ms.Close()

                Dim responseBytes = ms.ToArray()
                Dim encoding = New System.Text.ASCIIEncoding()

                Dim objXmlDocument As New XmlDocument
                objXmlDocument.LoadXml(encoding.GetString(responseBytes))

                Dim index As Integer = 0
                Dim objXmlNodeList As XmlNodeList = objXmlDocument.SelectSingleNode("GeocodeResponse/result/geometry/location").ChildNodes
                If objXmlNodeList.Count > 0 Then
                    For Each objXmlNode As XmlNode In objXmlNodeList
                        If index = 0 Then
                            objCity.YourCityLatitude = objXmlNode.InnerText
                        Else
                            objCity.YourCityLongitude = objXmlNode.InnerText
                        End If

                        index = index + 1
                    Next
                End If
            End If
        End Sub

        ''' <summary>
        ''' Builds the cities.
        ''' </summary>
        ''' <param name="drCities">The dr cities.</param>
        ''' <param name="shouldBuildSongCategories">if set to <c>true</c> [should build song categories].</param>
        ''' <param name="shouldBuildSongVotes">if set to <c>true</c> [should build song votes].</param><returns></returns>
        Private Function BuildCities(ByVal drCities As IDataReader, ByVal shouldBuildSongCategories As Boolean, ByVal shouldBuildSongVotes As Boolean) As Model.ZipCodeFinder.City
            Dim objCity As New Model.ZipCodeFinder.City

            With objCity
                .YourCity = If(HasColumn(drCities, "YourCity"), drCities("YourCity"), 0)
                .FoundCityZipCode = If(HasColumn(drCities, "ZipCode"), drCities("ZipCode"), String.Empty)
                .FoundCityName = If(HasColumn(drCities, "City"), drCities("City"), String.Empty)
                .FoundCityDistance = If(HasColumn(drCities, "Distance"), drCities("Distance"), String.Empty)
            End With

            Return objCity

        End Function

        ''' <summary>
        ''' Determines whether the reader has specified column.
        ''' </summary>
        ''' <param name="reader">The reader.</param>
        ''' <param name="columnName">Name of the column.</param><returns>
        '''   <c>true</c> if the specified reader has column; otherwise, <c>false</c>.
        ''' </returns>
        Private Function HasColumn(ByVal reader As IDataReader, ByVal columnName As String) As Boolean
            Try
                Return reader.GetOrdinal(columnName) >= 0
            Catch ex As IndexOutOfRangeException
                Return False
            End Try
            Return False
        End Function
#End Region

    End Class
End Namespace
