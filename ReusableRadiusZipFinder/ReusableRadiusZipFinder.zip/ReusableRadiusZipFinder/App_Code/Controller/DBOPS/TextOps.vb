﻿Imports Microsoft.VisualBasic
Imports System.Data

Namespace DBOPS
    Public Class TextOps
        Implements IDisposable

        Public cn As Generic.List(Of OleDb.OleDbConnection)
        Private cmd As Generic.List(Of OleDb.OleDbCommand)
        Private dr As Generic.List(Of OleDb.OleDbDataReader)

        Private da As Generic.List(Of OleDb.OleDbDataAdapter)
        Private ds As Generic.List(Of DataSet)
        Private dt As Generic.List(Of DataTable)


        Private Sub PrepareTable()
            If dt Is Nothing Then
                dt = New Generic.List(Of DataTable)
            End If
            dt.Add(New DataTable)
        End Sub
        Private Sub PrepareDataSet()
            If ds Is Nothing Then
                ds = New Generic.List(Of DataSet)
            End If
            ds.Add(New DataSet)
        End Sub
        Private Sub CreateAdapter(ByRef OleDbDataAdapter As OleDb.OleDbDataAdapter)
            If da Is Nothing Then
                da = New Generic.List(Of OleDb.OleDbDataAdapter)
            End If
            da.Add(OleDbDataAdapter)
        End Sub
        Private Sub OpenConnection()
            If cn Is Nothing Then
                cn = New Generic.List(Of OleDb.OleDbConnection)
            End If
            cn.Add(New OleDb.OleDbConnection(ConnectionString))
            MostRecentConnection.Open()
        End Sub

        Private Sub CreateCommand(ByRef OleDbCommand As OleDb.OleDbCommand)
            If cmd Is Nothing Then
                cmd = New Generic.List(Of OleDb.OleDbCommand)
            End If
            cmd.Add(OleDbCommand)
        End Sub
        Private Sub CreateReader(ByRef OleDbDataReader As OleDb.OleDbDataReader)
            If dr Is Nothing Then
                dr = New Generic.List(Of OleDb.OleDbDataReader)
            End If
            dr.Add(OleDbDataReader)
        End Sub


        Private Function MostRecentDataSet() As DataSet
            Return ds(ds.Count - 1)
        End Function
        Private Function MostRecentAdapter() As Data.Common.DbDataAdapter
            Return da(da.Count - 1)
        End Function
        Private Function MostRecentTable() As DataTable
            Return dt(dt.Count - 1)
        End Function
        Private Function MostRecentConnection() As Data.Common.DbConnection
            Return cn(cn.Count - 1)
        End Function
        Private Function MostRecentCommand() As Data.Common.DbCommand
            Return cmd(cmd.Count - 1)
        End Function
        Private Function MostRecentReader() As Data.Common.DbDataReader
            Return dr(dr.Count - 1)
        End Function

        Private auditer As AuditFactory
        Public Sub New(ByVal folder As String)
            Me.Folder = folder

            auditer = New AuditFactory
            'Me.Filename = filename
        End Sub
        Private _folder As String
        Public Property Folder() As String
            Get
                Return _folder
            End Get
            Set(ByVal value As String)
                _folder = value
            End Set
        End Property
        'Private _filename As String
        'Public Property Filename() As String
        '    Get
        '        Return _filename
        '    End Get
        '    Set(ByVal value As String)
        '        _filename = value
        '    End Set
        'End Property
        Public ReadOnly Property ConnectionString() As String
            Get
                Return "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" & Folder & "\;Extended Properties='text;HDR=Yes'"
            End Get
        End Property
        Public Function getReader(ByVal str As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As IDataReader
            OpenConnection()

            CreateCommand(New OleDb.OleDbCommand(str, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.Text
            If Not param Is Nothing Then

                For Each p As SqlClient.SqlParameter In param
                    If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                        p.Value = Nothing
                    End If
                    MostRecentCommand.Parameters.Add(p)
                Next p

            End If
            CreateReader(MostRecentCommand.ExecuteReader)

            'MostRecentConnection.Close()
            MostRecentCommand.Dispose()

            auditer.AddAudit(str, param)


            Return MostRecentReader()
        End Function

        Private disposedValue As Boolean = False        ' To detect redundant calls

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)

            If Not Me.disposedValue Then
                If disposing Then
                    ' TODO: free other state (managed objects).
                End If
                If Not da Is Nothing Then
                    For Each dataAdapter As Data.Common.DataAdapter In da
                        If Not dataAdapter Is Nothing Then
                            dataAdapter.Dispose()
                        End If
                    Next
                End If
                If Not dt Is Nothing Then
                    For Each dataTable As DataTable In dt
                        If Not dataTable Is Nothing Then
                            dataTable.Dispose()
                        End If
                    Next
                    dt = Nothing
                End If
                If Not ds Is Nothing Then
                    For Each dataSet As DataSet In ds
                        If Not dataSet Is Nothing Then
                            dataSet.Dispose()
                        End If
                    Next
                    ds = Nothing
                End If
                If Not dr Is Nothing Then
                    For Each reader As IDataReader In dr
                        If Not reader Is Nothing Then
                            If Not reader.IsClosed Then
                                reader.Close()
                            End If
                            reader.Dispose()
                        End If

                    Next
                    dr = Nothing
                End If

                If Not cn Is Nothing Then
                    For Each connection As Data.Common.DbConnection In cn
                        If Not connection Is Nothing Then
                            If Not connection.State = ConnectionState.Closed Then
                                connection.Close()
                            End If
                            connection.Dispose()
                        End If
                    Next
                End If
                If Not cmd Is Nothing Then
                    For Each command As Data.Common.DbCommand In cmd
                        If Not command Is Nothing Then
                            command.Dispose()
                        End If
                    Next
                End If
                auditer.StampAll()
            End If
            Me.disposedValue = True
            auditer = Nothing
        End Sub


#Region " IDisposable Support "
        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region

    End Class

End Namespace
