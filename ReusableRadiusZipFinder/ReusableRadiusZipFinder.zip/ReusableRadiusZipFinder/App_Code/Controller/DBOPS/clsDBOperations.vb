'CLASSES FOR DATABASE OPERATIONS
'NAMESPACE : DBOPS
'CLASS : clsDBOperations
'DEVELOPED BY : MAYUR PATIL
'CREATED ON : 26-10-2007
'UPDATE ON :

Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.HttpServerUtility
Imports System.Data
Imports System.Data.SqlClient
Imports System.IO
Imports System.Drawing
Imports System.Drawing.Imaging

Imports System.Web.Configuration


Namespace DBOPS
    Public Class Connections
        Inherits Generic.List(Of SqlConnection)
        Public Sub Close()
            For Each connection As Data.Common.DbConnection In Me
                If Not connection Is Nothing Then
                    If Not connection.State = ConnectionState.Closed Then
                        connection.Close()
                    End If
                    connection.Dispose()
                End If
            Next
        End Sub



    End Class

    Public Class asyncClsDBOps
        Implements IDisposable
        Private _myParameterBuilder As New Parameters
        Public Function createParameter(ByVal name As String, ByVal value As Object) As Data.Common.DbParameter
            Return _myParameterBuilder.createParameter(name, value)
        End Function

        Protected sqlstr As String
        Protected dr As SqlDataReader
        Protected conn As SqlConnection
        Public cmd As SqlCommand
        Public Delegate Function StubGetReader(ByVal str As String, ByVal param As System.Data.Common.DbParameter()) As IDataReader
        Public Class StateGetReader
            Public previousState As Object
            Public asyncStub As StubGetReader
            Public dataCommand As SqlCommand
        End Class

        Public Function BeginStoredProcedureReader(ByVal str As String, ByVal param As System.Data.Common.DbParameter(), _
                           ByVal callback As AsyncCallback, _
                           ByVal state As StateGetReader) As IAsyncResult
            OpenConnection()
            cmd = New SqlCommand(str, conn)

            cmd.CommandType = CommandType.StoredProcedure
            If Not param Is Nothing Then
                For Each p As SqlParameter In param
                    If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                        p.Value = Nothing
                    End If
                    cmd.Parameters.Add(p)
                Next p
            End If
            state.dataCommand = cmd
            Return cmd.BeginExecuteReader(callback, state)
        End Function

        Sub New()
            sqlstr = WebConfigurationManager.ConnectionStrings("constr").ConnectionString() & ";async=true"
        End Sub
        Public Sub OpenConnection()
            conn = New SqlConnection(sqlstr)
            conn.Open()
        End Sub

        Public Shared Function EndGetReader(ByVal ar As IAsyncResult) As IDataReader
            Dim ms As StateGetReader = DirectCast(ar.AsyncState, StateGetReader)
            Return ms.dataCommand.EndExecuteReader(ar)
        End Function
        Private disposedValue As Boolean = False        ' To detect redundant calls

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
            If Not Me.disposedValue Then
                If disposing Then
                    ' TODO: free other state (managed objects).
                End If
             
                If Not dr Is Nothing Then
                    For Each reader As IDataReader In dr
                        If Not reader Is Nothing Then
                            If Not reader.IsClosed Then
                                reader.Close()
                            End If
                            reader.Dispose()
                        End If

                    Next
                    dr = Nothing
                End If

                If Not conn Is Nothing Then
                    conn.Close()
                End If
                If Not cmd Is Nothing Then
                  cmd.Dispose()
                 End If
            End If
            Me.disposedValue = True
        End Sub


#Region " IDisposable Support "
        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region
    End Class

    Public Class clsDBOperations
        Implements IDisposable

        Public cn As Connections 'Generic.List(Of SqlConnection)
        Private cmd As Generic.List(Of SqlCommand)
        Private dr As Generic.List(Of SqlDataReader)

        Private da As Generic.List(Of SqlDataAdapter)
        Private ds As Generic.List(Of DataSet)
        Private dt As Generic.List(Of DataTable)


        Protected sqlstr As String
        Private auditer As New AuditFactory

        Sub New()
            sqlstr = WebConfigurationManager.ConnectionStrings("constr").ConnectionString()

        End Sub


        Public ReadOnly Property LoggingEnabled() As Boolean
            Get
                Return False 'WebConfigurationManager.AppSettings("Logging.Database")
            End Get
        End Property
        Public Function getConnection() As SqlConnection
            OpenConnection()
            Return MostRecentConnection()
        End Function
        Public Function getConnectionString() As String
            Return sqlstr
        End Function
        Private Sub PrepareTable()
            If dt Is Nothing Then
                dt = New Generic.List(Of DataTable)
            End If
            dt.Add(New DataTable)
        End Sub
        Private Sub PrepareDataSet()
            If ds Is Nothing Then
                ds = New Generic.List(Of DataSet)
            End If
            ds.Add(New DataSet)
        End Sub
        Private Sub CreateAdapter(ByRef SQLAdapter As SqlDataAdapter)
            If da Is Nothing Then
                da = New Generic.List(Of SqlDataAdapter)
            End If
            da.Add(SQLAdapter)
        End Sub
        Protected Sub OpenConnection()
            If cn Is Nothing Then
                cn = New Connections
            End If

            If cn.Count = 0 Then
                cn.Add(New SqlConnection(sqlstr))
                MostRecentConnection.Open()
            Else
                Dim hasOpenReader As Boolean = False
                If Not MostRecentReader() Is Nothing Then
                    hasOpenReader = Not MostRecentReader.IsClosed
                End If
                If MostRecentConnection.State = ConnectionState.Executing Or MostRecentConnection.State = ConnectionState.Fetching Or hasOpenReader Or MostRecentConnection.State = ConnectionState.Closed Or MostRecentConnection.State = ConnectionState.Broken Then
                    cn.Add(New SqlConnection(sqlstr))
                    MostRecentConnection.Open()
                End If
            End If


        End Sub

        Protected Sub CreateCommand(ByRef SQLCommand As SqlCommand)
            If cmd Is Nothing Then
                cmd = New Generic.List(Of SqlCommand)
            End If
            SQLCommand.CommandTimeout = 100
            cmd.Add(SQLCommand)
        End Sub
        Protected Sub CreateReader(ByRef SQLDataReader As SqlDataReader)
            If dr Is Nothing Then
                dr = New Generic.List(Of SqlDataReader)
            End If
            dr.Add(SQLDataReader)
        End Sub


        Protected Function MostRecentDataSet() As DataSet
            Return ds(ds.Count - 1)
        End Function
        Protected Function MostRecentAdapter() As SqlDataAdapter
            Return da(da.Count - 1)
        End Function
        Protected Function MostRecentTable() As DataTable
            Return dt(dt.Count - 1)
        End Function
        Protected Function MostRecentConnection() As SqlConnection
            Return cn(cn.Count - 1)
        End Function
        Protected Function MostRecentCommand() As SqlCommand
            Return cmd(cmd.Count - 1)
        End Function
        Protected Function MostRecentReader() As SqlDataReader
            If Not dr Is Nothing Then

                If Not dr.Count = 0 Then
                    Return dr(dr.Count - 1)
                End If

            End If
            Return Nothing
        End Function

        Private _myParameterBuilder As New Parameters
        Public Function createParameter(ByVal name As String, ByVal value As Object) As Data.Common.DbParameter
            Return _myParameterBuilder.createParameter(name, value)
        End Function
        Public Function createOutputParameter(ByVal name As String, ByVal value As Object) As Data.Common.DbParameter
            Return _myParameterBuilder.createOutputParameter(name, value)
        End Function



        Function SelectData(ByVal spName As String, ByVal param As System.Data.Common.DbParameter()) As DataTable
            Return getData(spName, param)
        End Function



#Region " Execute to Query"


        Function SpExecuteScalar(ByVal spName As String, ByVal param As System.Data.Common.DbParameter()) As Integer
            Return spExeScalar(spName, param)
        End Function

        Function exeQuery(ByVal query As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As String
            Dim result As String = ""
            OpenConnection()
            CreateCommand(New SqlCommand(query, MostRecentConnection))


            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If

            Try
                result = MostRecentCommand.ExecuteNonQuery()
            Catch ex As Exception
                auditer.AddErrordAudit(query, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try

            auditer.AddAudit(query, param)
            Return result
        End Function
        Function getScaler(ByVal query As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As String
            Dim str As String
            OpenConnection()
            CreateCommand(New SqlCommand(query, MostRecentConnection))


            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                str = MostRecentCommand.ExecuteScalar()
            Catch ex As Exception
                auditer.AddErrordAudit(query, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try
            auditer.AddAudit(query, param)
            Return str
        End Function


        Function spExecuteNonQuery(ByVal spname As String, ByVal param As System.Data.Common.DbParameter()) As String
            Dim Result As Integer
            OpenConnection()
            CreateCommand(New SqlCommand(spname, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                Result = MostRecentCommand.ExecuteNonQuery()
            Catch ex As Exception
                auditer.AddErrordAudit(spname, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try

            auditer.AddAudit(spname, param)
            Return Result
        End Function
        Function spExeScalar(ByVal spname As String, ByVal param As System.Data.Common.DbParameter()) As Integer
            Dim Result As Integer
            OpenConnection()
            CreateCommand(New SqlCommand(spname, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                Result = MostRecentCommand.ExecuteScalar()
            Catch ex As Exception
                auditer.AddErrordAudit(spname, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try
            auditer.AddAudit(spname, param)

            Return Result
        End Function
        Function spExeScalarString(ByVal spname As String, ByVal param As System.Data.Common.DbParameter()) As String
            Dim Result As String
            OpenConnection()
            CreateCommand(New SqlCommand(spname, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                Result = MostRecentCommand.ExecuteScalar()
            Catch ex As Exception
                auditer.AddErrordAudit(spname, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try
            auditer.AddAudit(spname, param)

            Return Result
        End Function

#End Region
#Region " Execute to DataTable "

        Function getData(ByVal query As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As DataTable

            PrepareTable()
            OpenConnection()
            CreateAdapter(New SqlDataAdapter(query, MostRecentConnection))


            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentAdapter.SelectCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                MostRecentAdapter.Fill(MostRecentTable)
            Catch ex As Exception
                auditer.AddErrordAudit(query, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentAdapter.Dispose()
            End Try
            auditer.AddAudit(query, param)

            Return MostRecentTable()

        End Function

        Function spGetData(ByVal spname As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As DataTable
            PrepareTable()
            OpenConnection()

            CreateCommand(New SqlCommand(spname, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            'MostRecentCommand.CommandTimeout = 100
            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentCommand.Parameters.Add(parameter)
                Next
            End If

            CreateAdapter(New SqlDataAdapter(MostRecentCommand))
            Try

                MostRecentAdapter.Fill(MostRecentTable)
            Catch ex As Exception
                auditer.AddErrordAudit(spname, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
                MostRecentAdapter.Dispose()
            End Try
            auditer.AddAudit(spname, param)

            Return MostRecentTable()
        End Function
        Function spgetDataTable(ByVal spname As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As DataTable
            Return spGetData(spname, param)
        End Function

        Function getDataSet(ByVal query As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As DataSet
            PrepareDataSet()
            OpenConnection()

            CreateAdapter(New SqlDataAdapter())

            MostRecentAdapter.SelectCommand = New SqlCommand
            MostRecentAdapter.SelectCommand.CommandText = query
            MostRecentAdapter.SelectCommand.Connection = MostRecentConnection()

            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentAdapter.SelectCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                MostRecentAdapter.Fill(MostRecentDataSet)
            Catch ex As Exception
                auditer.AddErrordAudit(query, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentAdapter.Dispose()
            End Try
            auditer.AddAudit(query, param)

            Return MostRecentDataSet()
        End Function

        Function getSpDataSet(ByVal spname As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As DataSet
            PrepareDataSet()
            OpenConnection()

            CreateAdapter(New SqlDataAdapter())


            MostRecentAdapter.SelectCommand = New SqlCommand
            MostRecentAdapter.SelectCommand.CommandText = spname
            MostRecentAdapter.SelectCommand.CommandType = CommandType.StoredProcedure
            MostRecentAdapter.SelectCommand.Connection = MostRecentConnection()

            If Not param Is Nothing Then
                For Each parameter As SqlParameter In param
                    MostRecentAdapter.SelectCommand.Parameters.Add(parameter)
                Next
            End If
            Try
                MostRecentAdapter.Fill(MostRecentDataSet)
            Catch ex As Exception
                auditer.AddErrordAudit(spname, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentAdapter.Dispose()
            End Try
            auditer.AddAudit(spname, param)

            Return MostRecentDataSet()
        End Function
#End Region



#Region " Reader "
        Public Function GetSpTableDataReader(ByVal spName As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As IDataReader
            Return getSpReader(spName, param)
        End Function

        Public Function getReader(ByVal str As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As IDataReader
            Try
                OpenConnection()

                CreateCommand(New SqlCommand(str, MostRecentConnection))


                MostRecentCommand.CommandType = CommandType.Text
                If Not param Is Nothing Then

                    For Each p As SqlParameter In param
                        If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                            p.Value = Nothing
                        End If
                        MostRecentCommand.Parameters.Add(p)
                    Next p

                End If
                Try
                    CreateReader(MostRecentCommand.ExecuteReader)
                Catch ex As Exception
                    auditer.AddErrordAudit(str, param)
                    MostRecentConnection.Close()
                    Throw ex
                End Try
            Finally
                MostRecentCommand.Dispose()
            End Try
            auditer.AddAudit(str, param)


            Return MostRecentReader()
        End Function


        Public Function getSpReader(ByVal str As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As IDataReader
            Try
                OpenConnection()
                CreateCommand(New SqlCommand(str, MostRecentConnection))


                MostRecentCommand.CommandType = CommandType.StoredProcedure
                'MostRecentCommand.CommandTimeout = 50

                If Not param Is Nothing Then
                    For Each p As SqlParameter In param
                        If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                            p.Value = Nothing
                        End If
                        MostRecentCommand.Parameters.Add(p)
                    Next p
                End If
                Try
                    CreateReader(MostRecentCommand.ExecuteReader)
                Catch ex As Exception
                    auditer.AddErrordAudit(str, param)
                    MostRecentConnection.Close()
                    Throw ex
                End Try


            Finally
                MostRecentCommand.Dispose()
            End Try
            auditer.AddAudit(str, param)

            Return MostRecentReader()
        End Function

#End Region
        Function InsertData(ByVal spName As String, ByVal param As System.Data.Common.DbParameter(), ByVal outputParameter As String) As Integer
            OpenConnection()
            CreateCommand(New SqlCommand(spName, MostRecentConnection))


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            Dim paramOutputParameter As SqlParameter
            Dim returnParamter As Integer

            If Not outputParameter Is Nothing Then
                paramOutputParameter = New SqlParameter(outputParameter, SqlDbType.Int)
                paramOutputParameter.Direction = ParameterDirection.Output
                MostRecentCommand.Parameters.Add(paramOutputParameter)
            End If
            'Dim p As New SqlParameter
            'cmd.Parameters.Add(param)
            If Not param Is Nothing Then
                For Each p In param
                    If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                        p.Value = Nothing
                    End If
                    MostRecentCommand.Parameters.Add(p)
                Next p
            End If
            Try
                MostRecentCommand.ExecuteNonQuery()
                If Not outputParameter Is Nothing Then
                    returnParamter = CInt(paramOutputParameter.Value)
                End If
                auditer.AddAudit(spName, param)
            Catch ex As Exception
                auditer.AddErrordAudit(spName, param)
                Throw ex
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try


            Return returnParamter

        End Function

        Function InsertData(ByVal spName As String, ByVal param As System.Data.Common.DbParameter(), ByVal outputParameter As String, ByVal outputType As String) As String
            Try
                OpenConnection()
                CreateCommand(New SqlCommand(spName, MostRecentConnection))

                MostRecentCommand.CommandType = CommandType.StoredProcedure
                Dim paramOutputParameter As SqlParameter
                Dim returnParamter As String

                If Not outputParameter Is Nothing Then
                    If outputType.Equals("String") Then
                        paramOutputParameter = New SqlParameter(outputParameter, SqlDbType.VarChar, 50)
                    Else
                        paramOutputParameter = New SqlParameter(outputParameter, SqlDbType.Int)
                    End If

                    paramOutputParameter.Direction = ParameterDirection.Output
                    MostRecentCommand.Parameters.Add(paramOutputParameter)

                    Dim p As New SqlParameter
                    'cmd.Parameters.Add(param)
                    If Not param Is Nothing Then
                        For Each p In param
                            If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                                p.Value = Nothing
                            End If
                            MostRecentCommand.Parameters.Add(p)
                        Next p
                    End If
                    Try
                        MostRecentCommand.ExecuteNonQuery()
                    Catch ex As Exception
                        auditer.AddErrordAudit(spName, param)
                        Throw ex
                    End Try
                    If Not outputParameter Is Nothing Then
                        returnParamter = paramOutputParameter.Value
                    End If
                    auditer.AddAudit(spName, param)
                    Return returnParamter
                Else
                    Throw New Exception("Error - No SQL Parameter has been passed to the InsertData function for " & spName)
                End If
            Finally
                MostRecentConnection.Close()
                MostRecentCommand.Dispose()
            End Try
            Return Nothing
        End Function

        Public Function CreateTransactionCommand() As Data.Common.DbCommand
            Dim tran As System.Data.Common.DbTransaction
            OpenConnection()
            tran = MostRecentConnection.BeginTransaction
            CreateCommand(New SqlCommand)

            MostRecentCommand.Connection = MostRecentConnection()
            MostRecentCommand.Transaction = tran
            Return MostRecentCommand()
        End Function


        Public Function spCreateStoredProcedureCommand(ByVal spname As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As Data.Common.DbCommand

            'OpenConnection()
            'CreateCommand(New SqlCommand)


            MostRecentCommand.CommandType = CommandType.StoredProcedure
            MostRecentCommand.CommandText = spname
            MostRecentCommand.Parameters.Clear()

            For Each p As System.Data.Common.DbParameter In param
                If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                    p.Value = Nothing
                End If
                MostRecentCommand.Parameters.Add(p)
            Next

            auditer.AddAudit(spname, param)

            Return MostRecentCommand()
        End Function
        Public Function spCreateQueryCommand(ByVal commandText As String, Optional ByVal param As System.Data.Common.DbParameter() = Nothing) As Data.Common.DbCommand

            'OpenConnection()
            'CreateCommand(New SqlCommand)


            MostRecentCommand.CommandType = CommandType.Text
            MostRecentCommand.CommandText = commandText
            MostRecentCommand.Parameters.Clear()

            For Each p As System.Data.Common.DbParameter In param
                If p.Direction = ParameterDirection.InputOutput And p.Value Is Nothing Then
                    p.Value = Nothing
                End If
                MostRecentCommand.Parameters.Add(p)
            Next

            auditer.AddAudit(commandText, param)

            Return MostRecentCommand()
        End Function


        Private disposedValue As Boolean = False        ' To detect redundant calls

        ' IDisposable
        Protected Overridable Sub Dispose(ByVal disposing As Boolean)
            If Not Me.disposedValue Then
                If disposing Then
                    ' TODO: free other state (managed objects).
                End If
                If Not da Is Nothing Then
                    For Each dataAdapter As Data.Common.DataAdapter In da
                        If Not dataAdapter Is Nothing Then
                            dataAdapter.Dispose()
                        End If
                    Next
                End If
                If Not dt Is Nothing Then
                    For Each dataTable As DataTable In dt
                        If Not dataTable Is Nothing Then
                            dataTable.Dispose()
                        End If
                    Next
                    dt = Nothing
                End If
                If Not ds Is Nothing Then
                    For Each dataSet As DataSet In ds
                        If Not dataSet Is Nothing Then
                            dataSet.Dispose()
                        End If
                    Next
                    ds = Nothing
                End If
                If Not dr Is Nothing Then
                    For Each reader As IDataReader In dr
                        If Not reader Is Nothing Then
                            If Not reader.IsClosed Then
                                reader.Close()
                            End If
                            reader.Dispose()
                        End If

                    Next
                    dr = Nothing
                End If

                If Not cn Is Nothing Then
                    cn.Close()
                End If
                If Not cmd Is Nothing Then
                    For Each command As Data.Common.DbCommand In cmd
                        If Not command Is Nothing Then
                            command.Dispose()
                        End If
                    Next
                End If
                auditer.StampAll()
            End If
            Me.disposedValue = True
        End Sub

        Public Shared Function HasColumnExists(ByRef reader As IDataReader, ByVal columnName As String) As Boolean

            reader.GetSchemaTable().DefaultView.RowFilter = "ColumnName= '" + columnName + "'"
            Return (reader.GetSchemaTable().DefaultView.Count > 0)

        End Function

#Region " IDisposable Support "
        ' This code added by Visual Basic to correctly implement the disposable pattern.
        Public Sub Dispose() Implements IDisposable.Dispose
            ' Do not change this code.  Put cleanup code in Dispose(ByVal disposing As Boolean) above.
            Dispose(True)
            GC.SuppressFinalize(Me)
        End Sub
#End Region
        Public Function getThumbNailImage(ByVal imagepath As String, ByVal imgWidth As Integer, ByVal imgHeight As Integer) As String
            'open the uploaded file
            Using image As System.Drawing.Image = System.Drawing.Image.FromFile("../Images/AppImages/" + imagepath)

                'generate thumbnail
                Dim objCallback As New System.Drawing.Image.GetThumbnailImageAbort(AddressOf ThumbnailCallback)
                Using thumbImage As System.Drawing.Image = image.GetThumbnailImage(imgWidth, imgHeight, objCallback, IntPtr.Zero)
                    '// save thumbnail
                    thumbImage.Save("testimagefile_thumb.jpg", ImageFormat.Jpeg)
                    Return "testimagefile_thumb.jpg"
                    '// show thumbnail
                    'imgThumb.ImageUrl = "testimagefile_thumb.jpg";

                    '// erase the uploaded file
                    'File.Delete(Server.MapPath("testimagefile.jpg"));
                End Using
            End Using


        End Function

        Function ThumbnailCallback() As Boolean
            Return False
        End Function
    End Class
End Namespace
