Imports Microsoft.VisualBasic
Imports System
Imports System.Web
Imports System.Web.HttpServerUtility
Imports System.Web.Configuration
Imports System.Data
Imports System.Data.SqlClient

Namespace DBOPS
    Public Class AuditInformation

        Private _description As String
        Public Property Description() As String
            Get
                Return _description
            End Get
            Set(ByVal value As String)
                _description = value
            End Set
        End Property

        Private _runTime As Integer
        Public Property RunTime() As Integer
            Get
                Return _runTime
            End Get
            Set(ByVal value As Integer)
                _runTime = value
            End Set
        End Property

    End Class
    Public Class AuditFactory
        Private timer As Diagnostics.Stopwatch
        Private Page As String
        Private Session As String
        Private AuditID As Integer
        Private AuditList As New Generic.List(Of AuditInformation)

        Public Sub New(Optional ByVal MyPageName As String = "")

            Session = "empty"
            If Not HttpContext.Current Is Nothing Then
                Page = HttpContext.Current.Request.Url.AbsoluteUri ' & "/" & HttpContext.Current.Request.RawUrl '& HttpContext.Current.Request.Path
                Dim threadID As Integer
                Integer.TryParse(Threading.Thread.CurrentThread.ManagedThreadId, threadID)
                Page = threadID & ":" & Page

                If Not HttpContext.Current.Session Is Nothing Then
                    Try
                        Session = HttpContext.Current.Session.SessionID
                    Catch
                        Session = "empty"
                    End Try
                End If
            Else
                Page = MyPageName
            End If
            timer = New Diagnostics.Stopwatch
            timer.Start()

        End Sub

        Public ReadOnly Property Enabled() As Boolean
            Get
                Return ConfigurationManager.AppSettings("Data.Audit.Enabled") = "True"
            End Get
        End Property
        Public Function GetRunTime() As Integer
            timer.Stop()
            Dim ts As TimeSpan = timer.Elapsed
            timer.Start()
            Return Math.Round(ts.TotalMilliseconds, 1)

        End Function
       
        Public Sub AddErrordAudit(ByVal Description As String, ByVal Parameters As Data.Common.DbParameter())
            AddAudit("!Error: " & Description, Parameters)
        End Sub

       
        Public Sub AddAudit(ByVal Description As String, ByVal Parameters As Data.Common.DbParameter())
            If Enabled Then
                Dim audit As New AuditInformation
                With audit
                    .Description = Description

                    Dim ParamString As String = " "
                    If Not Parameters Is Nothing Then
                        If Not Parameters.Length = 0 Then
                            Dim IsFirst As Boolean = True
                            For Each param As Data.Common.DbParameter In Parameters
                                If IsFirst Then
                                   
                                    ParamString = String.Concat(ParamString, " ")
                                    IsFirst = False
                                Else
                                    ParamString = String.Concat(ParamString, ", ")
                                End If
                                If param.Value Is DBNull.Value Or param.Value Is Nothing Then
                                    ParamString = String.Concat(ParamString, param.ParameterName, "=Null")
                                ElseIf param.Value.GetType().BaseType().FullName = "System.Enum" Then
                                    ParamString = String.Concat(ParamString, param.ParameterName, "='", CInt(param.Value), "'")
                                ElseIf TypeOf (param.Value) Is DateTime Then
                                    ParamString = String.Concat(ParamString, param.ParameterName, "='", Format(param.Value, "yyyy-MM-dd"), "'")
                                Else
                                    ParamString = String.Concat(ParamString, param.ParameterName, "='", param.Value, "'")
                                End If
                            Next

                        End If
                    End If
                    .Description = String.Concat(Description, ParamString)
                    .RunTime = GetRunTime()
                End With
                AuditList.Add(audit)

            End If

        End Sub
        Public Sub StampAll()
            If Enabled Then
                Dim connStr As String = WebConfigurationManager.ConnectionStrings("constr").ConnectionString()
                Using connection As New SqlConnection(connStr)

                    connection.Open()
                    For Each audit As AuditInformation In AuditList
                        Using command As New SqlCommand("AuditStamp", connection)
                            command.CommandType = CommandType.StoredProcedure
                            command.Parameters.Add(New SqlParameter("@Page", Page))
                            command.Parameters.Add(New SqlParameter("@Session", Session))

                            command.Parameters.Add(New SqlParameter("@Description", audit.Description))
                            command.Parameters.Add(New SqlParameter("@LengthOfTime", audit.RunTime))
                            If AuditID <> 0 Then
                                command.Parameters.Add(New SqlParameter("@AuditID", AuditID))
                                command.ExecuteScalar()
                            Else
                                AuditID = command.ExecuteScalar()
                            End If

                        End Using

                    Next
                    connection.Close()

                End Using
            End If
        End Sub
    End Class


End Namespace
