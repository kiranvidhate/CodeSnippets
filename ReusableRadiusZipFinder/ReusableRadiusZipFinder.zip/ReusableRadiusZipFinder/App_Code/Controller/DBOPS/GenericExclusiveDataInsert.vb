﻿Imports Microsoft.VisualBasic
Namespace DBOPS

    Public Class GenericExclusiveDataInsert

        Private _id As Integer
        Public Property ID() As Integer
            Get
                Return _id
            End Get
            Set(ByVal value As Integer)
                _id = value
            End Set
        End Property


        Private _alreadyExists As Boolean
        Public Property AlreadyExists() As Boolean
            Get
                Return _alreadyExists
            End Get
            Set(ByVal value As Boolean)
                _alreadyExists = value
            End Set
        End Property

    End Class

End Namespace