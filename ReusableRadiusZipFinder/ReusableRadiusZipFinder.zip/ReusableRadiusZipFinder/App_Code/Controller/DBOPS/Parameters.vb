﻿Imports Microsoft.VisualBasic
Imports System.Data

Namespace DBOPS

    Public Class Parameters
        Public Function createParameter(ByVal name As String, ByVal value As Object) As Data.Common.DbParameter
            Dim sqlParameter As New SqlClient.SqlParameter(name, value)
            Return sqlParameter
        End Function
        Public Function createOutputParameter(ByVal name As String, ByVal value As Object) As Data.Common.DbParameter
            Dim sqlParameter As New SqlClient.SqlParameter(name, value)
            sqlParameter.Direction = ParameterDirection.Output
            Return sqlParameter
        End Function
    End Class

End Namespace