﻿Imports Microsoft.VisualBasic

Namespace Model.ZipCodeFinder

    ''' <summary>
    ''' 
    ''' </summary>
    Public Class City

#Region "Public Properties"

        Private _yourZipCode As String

        ''' <summary>
        ''' Gets or sets your zip code.
        ''' </summary>
        ''' <value>
        ''' Your zip code.
        ''' </value>
        Public Property YourZipCode() As String
            Get
                Return _yourZipCode
            End Get
            Set(ByVal value As String)
                _yourZipCode = value
            End Set
        End Property

        Private _radius As Integer
        ''' <summary>
        ''' Gets or sets the radius.
        ''' </summary>
        ''' <value>
        ''' The radius.
        ''' </value>
        Public Property Radius() As Integer
            Get
                Return _radius
            End Get
            Set(ByVal value As Integer)
                _radius = value
            End Set
        End Property

        Private _yourCity As String

        ''' <summary>
        ''' Gets or sets your city.
        ''' </summary>
        ''' <value>
        ''' Your city.
        ''' </value>
        Public Property YourCity As String
            Get
                Return _yourCity
            End Get
            Set(ByVal value As String)
                _yourCity = value
            End Set
        End Property

        Private _foundCityZipCode As String

        ''' <summary>
        ''' Gets or sets the found city zip code.
        ''' </summary>
        ''' <value>
        ''' The found city zip code.
        ''' </value>
        Public Property FoundCityZipCode As String
            Get
                Return _foundCityZipCode
            End Get
            Set(ByVal value As String)
                _foundCityZipCode = value
            End Set
        End Property

        Private _foundCityName As String

        ''' <summary>
        ''' Gets or sets the name of the found city.
        ''' </summary>
        ''' <value>
        ''' The name of the found city.
        ''' </value>
        Public Property FoundCityName As String
            Get
                Return _foundCityName
            End Get
            Set(ByVal value As String)
                _foundCityName = value
            End Set
        End Property

        Private _foundCityDistance As String

        ''' <summary>
        ''' Gets or sets the found city distance.
        ''' </summary>
        ''' <value>
        ''' The found city distance.
        ''' </value>
        Public Property FoundCityDistance As String
            Get
                Return _foundCityDistance
            End Get
            Set(ByVal value As String)
                _foundCityDistance = value
            End Set
        End Property

        Private _latitude As String

      
        ''' <summary>
        ''' Gets or sets your city latitude.
        ''' </summary>
        ''' <value>
        ''' Your city latitude.
        ''' </value>
        Public Property YourCityLatitude As String
            Get
                Return _latitude
            End Get
            Set(ByVal value As String)
                _latitude = value
            End Set
        End Property

        Private _longitude As String

        ''' <summary>
        ''' Gets or sets your city longitude.
        ''' </summary>
        ''' <value>
        ''' Your city longitude.
        ''' </value>
        Public Property YourCityLongitude As String
            Get
                Return _longitude
            End Get
            Set(ByVal value As String)
                _longitude = value
            End Set
        End Property
#End Region

    End Class
End Namespace