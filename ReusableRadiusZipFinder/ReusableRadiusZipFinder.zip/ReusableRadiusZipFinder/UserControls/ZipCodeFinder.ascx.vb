﻿Imports Model.ZipCodeFinder

Partial Class UserControls_ZipCodeFinder
    Inherits System.Web.UI.UserControl

#Region "Class Variables"
    Dim objCity As New City()
#End Region

#Region "Class Events"

    ''' <summary>
    ''' Handles the Click event of the btnSearch control.
    ''' </summary>
    ''' <param name="sender">The source of the event.</param>
    ''' <param name="e">The <see cref="System.EventArgs" /> instance containing the event data.</param>
    Protected Sub btnSearch_Click(ByVal sender As Object, ByVal e As System.EventArgs) Handles btnSearch.Click
        If ValidData() Then
            Dim lstCitiesList As New Generic.List(Of Model.ZipCodeFinder.City)
            Dim wsCities As New WSCities()

            objCity.Radius = txtRadius.Text
            objCity.YourZipCode = txtBaseZip.Text
            objCity.YourCity = txtBaseCity.Text

            lstCitiesList = wsCities.FindZipCodesInRadius(objCity)

            If lstCitiesList.Count > 0 Then
                lblCount.Text = lstCitiesList.Count()
                dtgCities.DataSource = lstCitiesList
                dtgCities.DataBind()
            Else
                UpdateDatabase()
            End If

            ' ''http://maps.googleapis.com/maps/api/geocode/xml?address=nashik&sensor=false
            ' ''https://developers.google.com/maps/documentation/geocoding/#GeocodingRequests
        Else
            lblCount.Text = "Invalid Input..."
        End If
    End Sub
#End Region

#Region "Private Methods"
    ''' <summary>
    ''' Valids the data.
    ''' </summary><returns></returns>
    Protected Function ValidData() As Boolean
        If String.IsNullOrEmpty(txtBaseCity.Text) Or String.IsNullOrEmpty(txtBaseZip.Text) Or String.IsNullOrEmpty(txtRadius.Text) Then
            Return False
        End If
        Return True
    End Function

    ''' <summary>
    ''' Updates the database.
    ''' </summary>
    Protected Sub UpdateDatabase()
        Dim lstCitiesList As New Generic.List(Of Model.ZipCodeFinder.City)
        Dim wsCities As New WSCities()
        wsCities.AddCity(objCity)
        lstCitiesList = wsCities.FindZipCodesInRadius(objCity)

        If lstCitiesList.Count > 0 Then
            lblCount.Text = lstCitiesList.Count()
            dtgCities.DataSource = lstCitiesList
            dtgCities.DataBind()
        Else
            lblCount.Text = "No Data Found..."
        End If
    End Sub
#End Region

End Class
